"""Produce document-level abbreviation definitions from BioC abbreviation tables.

The explorer remains the auditable parsing engine.  This command adds a small,
production-facing layer that emits expander-compatible JSONL plus compact
section decisions and a reproducible manifest.  Source BioC is never modified.
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
from pathlib import Path
import time
from typing import Any, Iterable, Mapping

from ..config import add_config_arguments, config_overrides
from ..logging_utils import configure_logging
from . import explore_bioc_abbr_tables_jev as hybrid


DEFINITIONS_FILENAME = "definitions.jsonl.gz"
DECISIONS_FILENAME = "section_decisions.jsonl.gz"


def _iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"Invalid JSONL at {path}:{line_number}") from error
            if not isinstance(value, dict):
                raise ValueError(f"Expected an object at {path}:{line_number}")
            yield value


def _replace_with_retry(temporary: Path, destination: Path) -> None:
    for attempt in range(10):
        try:
            temporary.replace(destination)
            return
        except PermissionError:
            if attempt == 9:
                raise
            time.sleep(min(0.05 * (2**attempt), 1.0))


def _open_atomic_gzip(path: Path):
    temporary = path.with_name(f".{path.name}.tmp")
    raw = temporary.open("wb")
    compressed = gzip.GzipFile(
        filename="",
        mode="wb",
        fileobj=raw,
        mtime=0,
    )
    return temporary, raw, compressed


def _finish_atomic_gzip(
    temporary: Path, raw, compressed: gzip.GzipFile, destination: Path
) -> None:
    compressed.close()
    raw.flush()
    os.fsync(raw.fileno())
    raw.close()
    _replace_with_retry(temporary, destination)


def _pair_output(pair: Mapping[str, Any]) -> dict[str, Any] | None:
    orientation = str(pair.get("orientation") or "")
    if orientation == "FIRST_IS_SF":
        short, long = pair.get("first"), pair.get("second")
    elif orientation == "SECOND_IS_SF":
        short, long = pair.get("second"), pair.get("first")
    else:
        return None
    short = hybrid._canonical_short_form(str(short or ""))
    long = hybrid._canonical_long_form(str(long or ""))
    if not short or not long:
        return None
    occurrences = pair.get("source_occurrences") or [
        pair.get("source_passage_indexes") or []
    ]
    return {
        "SF": short,
        "LF": long,
        "orientation": orientation,
        "source_passage_indexes": list(pair.get("source_passage_indexes") or []),
        "source_occurrences": [list(value) for value in occurrences],
    }


def _decision_output(row: Mapping[str, Any]) -> dict[str, Any]:
    base = row.get("base") or {}
    candidate = row.get("final_candidate")
    definitions = []
    if isinstance(candidate, Mapping):
        definitions = [
            value
            for pair in candidate.get("pairs") or []
            if (value := _pair_output(pair)) is not None
        ]
    withheld = [
        value
        for pair in row.get("withheld_pairs") or []
        if (value := _pair_output(pair)) is not None
    ]
    return {
        "source": {
            "filename": base.get("filename"),
            "document_id": base.get("document_id"),
            "start_index": base.get("start_index"),
        },
        "disposition": row.get("disposition"),
        "decision_source": row.get("decision_source"),
        "decision_reason": row.get("decision_reason"),
        "parser": {
            "pattern": candidate.get("pattern") if isinstance(candidate, Mapping) else None,
            "subpattern": candidate.get("subpattern") if isinstance(candidate, Mapping) else None,
            "end_index": candidate.get("end_index") if isinstance(candidate, Mapping) else None,
            "warnings": list(candidate.get("warnings") or []) if isinstance(candidate, Mapping) else [],
        },
        "definitions": definitions,
        "withheld_definitions": withheld,
        "pair_reviews": list(row.get("pair_reviews") or []),
        "tail_diagnostics": list(row.get("tail_diagnostics") or []),
        "jev_response": row.get("jev_response"),
        "pair_jev_response": row.get("pair_jev_response"),
        "error": row.get("error"),
    }


def write_annotation_outputs(output_dir: Path | str) -> int:
    """Convert a complete explorer report into deterministic production outputs."""
    target = Path(output_dir)
    manifest_path = target / "manifest.json"
    sequences_path = target / "sequences.jsonl"
    if not manifest_path.exists() or not sequences_path.exists():
        raise FileNotFoundError(
            f"Cannot annotate without both {manifest_path} and {sequences_path}"
        )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not manifest.get("complete"):
        raise ValueError("Refusing to publish definitions from an incomplete report")

    definitions_path = target / DEFINITIONS_FILENAME
    decisions_path = target / DECISIONS_FILENAME
    definitions_tmp, definitions_raw, definitions_gzip = _open_atomic_gzip(
        definitions_path
    )
    decisions_tmp, decisions_raw, decisions_gzip = _open_atomic_gzip(decisions_path)
    seen: set[tuple[str, str, str]] = set()
    definition_count = 0
    decision_count = 0
    review_count = 0
    accepted = {
        hybrid.Disposition.ACCEPTED.value,
        hybrid.Disposition.ACCEPTED_WITH_REVIEW.value,
    }
    try:
        for row in _iter_jsonl(sequences_path):
            decision = _decision_output(row)
            decisions_gzip.write(
                (json.dumps(decision, ensure_ascii=False) + "\n").encode("utf-8")
            )
            decision_count += 1
            review_count += len(decision["withheld_definitions"])
            if row.get("disposition") not in accepted:
                continue
            document_id = str((row.get("base") or {}).get("document_id") or "")
            for pair in decision["definitions"]:
                key = (
                    document_id,
                    hybrid._normalized(pair["SF"]),
                    hybrid._normalized(pair["LF"]),
                )
                if not document_id or key in seen:
                    continue
                seen.add(key)
                definitions_gzip.write(
                    (
                        json.dumps(
                            {"ID": document_id, "SF": pair["SF"], "LF": pair["LF"]},
                            ensure_ascii=False,
                        )
                        + "\n"
                    ).encode("utf-8")
                )
                definition_count += 1
        _finish_atomic_gzip(
            definitions_tmp, definitions_raw, definitions_gzip, definitions_path
        )
        _finish_atomic_gzip(
            decisions_tmp, decisions_raw, decisions_gzip, decisions_path
        )
    except Exception:
        definitions_gzip.close()
        decisions_gzip.close()
        definitions_raw.close()
        decisions_raw.close()
        raise

    manifest["annotation"] = {
        "schema_version": 1,
        "policy_version": hybrid.JEV_POLICY_VERSION,
        "definitions_file": DEFINITIONS_FILENAME,
        "definitions_sha256": hybrid._sha256(definitions_path),
        "definition_count": definition_count,
        "deduplication_key": ["ID", "normalized SF", "normalized LF"],
        "section_decisions_file": DECISIONS_FILENAME,
        "section_decisions_sha256": hybrid._sha256(decisions_path),
        "section_decision_count": decision_count,
        "withheld_definition_count": review_count,
    }
    hybrid._atomic_write_json(manifest_path, manifest)
    return definition_count


def run(
    config_path: Path | str,
    overrides: Mapping[str, Any] | None = None,
    *,
    output_dir: Path | str,
    dictionary_path: Path | str | None = None,
    model: str = hybrid.DEFAULT_MODEL,
    confidence_threshold: float = hybrid.DEFAULT_CONFIDENCE_THRESHOLD,
    cache_path: Path | str | None = None,
    max_jev_calls: int | None = None,
    jev_cache_only: bool = False,
    resume: bool = False,
    jev_all: bool = False,
    jev_retries: int = 3,
    jev_retry_delay: float = 1.0,
) -> int:
    hybrid.run(
        config_path,
        overrides,
        report_dir=output_dir,
        dictionary_path=dictionary_path,
        model=model,
        confidence_threshold=confidence_threshold,
        cache_path=cache_path,
        max_jev_calls=max_jev_calls,
        jev_cache_only=jev_cache_only,
        resume=resume,
        jev_all=jev_all,
        jev_retries=jev_retries,
        jev_retry_delay=jev_retry_delay,
    )
    return write_annotation_outputs(output_dir)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, conflict_handler="resolve")
    parser.add_argument("--config", type=Path, default=Path("config/pipeline.yaml"))
    add_config_arguments(parser)
    parser.add_argument("--dictionary", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--jev-model", default=hybrid.DEFAULT_MODEL)
    parser.add_argument(
        "--jev-confidence-threshold",
        type=float,
        default=hybrid.DEFAULT_CONFIDENCE_THRESHOLD,
    )
    parser.add_argument("--jev-cache", type=Path)
    parser.add_argument("--jev-cache-only", action="store_true")
    parser.add_argument("--max-jev-calls", type=int)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--jev-all", action="store_true")
    parser.add_argument("--jev-retries", type=int, default=3)
    parser.add_argument("--jev-retry-delay", type=float, default=1.0)
    parser.add_argument(
        "--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"]
    )
    parser.add_argument("--log-file", type=Path)
    args = parser.parse_args()
    configure_logging(args.log_level, args.log_file)
    run(
        args.config,
        config_overrides(args),
        output_dir=args.output_dir,
        dictionary_path=args.dictionary,
        model=args.jev_model,
        confidence_threshold=args.jev_confidence_threshold,
        cache_path=args.jev_cache,
        max_jev_calls=args.max_jev_calls,
        jev_cache_only=args.jev_cache_only,
        resume=args.resume,
        jev_all=args.jev_all,
        jev_retries=args.jev_retries,
        jev_retry_delay=args.jev_retry_delay,
    )


if __name__ == "__main__":
    main()
