"""Detect structured abbreviation sections in BioC XML collections.

The detector is observational: it logs recognized short-form/long-form pairs
and unrecognized ``ABBR`` passages without changing the BioC collection.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import logging
from pathlib import Path
import re
from typing import Sequence
import xml.etree.ElementTree as ET

import bioc

from ..bioc_io import load_collection
from ..config import add_config_arguments, config_overrides, load_config
from ..logging_utils import configure_logging


LOG = logging.getLogger(__name__)
_TITLE_TYPES = frozenset({"title", "title_1"})
_PAIR_SEPARATORS = frozenset({",", ":", "="})
_NON_ABBREVIATION_TITLES = frozenset({"citations", "consent for publication"})
_ABBREVIATION_BOILERPLATE = "the following abbreviations are used in this manuscript"


def _section_type(passage: bioc.BioCPassage) -> object:
    return (passage.infons or {}).get("section_type")


def _passage_type(passage: bioc.BioCPassage) -> object:
    return (passage.infons or {}).get("type")


def _text(passage: bioc.BioCPassage) -> str:
    return passage.text or ""


def _is_abbr(passage: bioc.BioCPassage) -> bool:
    return _section_type(passage) == "ABBR"


def _is_title(passage: bioc.BioCPassage) -> bool:
    return _is_abbr(passage) and _passage_type(passage) in _TITLE_TYPES


def _normalized_text(passage: bioc.BioCPassage) -> str:
    return " ".join(_text(passage).split()).strip(" .:").casefold()


def _is_boilerplate(passage: bioc.BioCPassage) -> bool:
    return _normalized_text(passage) == _ABBREVIATION_BOILERPLATE


def _is_known_non_abbreviation_title(passage: bioc.BioCPassage) -> bool:
    return _is_title(passage) and _normalized_text(passage) in _NON_ABBREVIATION_TITLES


def _is_narrative(passage: bioc.BioCPassage) -> bool:
    """Identify long body prose incorrectly tagged as an ABBR paragraph."""
    return _passage_type(passage) == "paragraph" and len(_text(passage).strip()) > 200


def _context(
    filename: Path | str,
    document: bioc.BioCDocument,
    passage: bioc.BioCPassage,
    location: int,
) -> str:
    source = Path(filename).name
    document_name = document.id or "<unnamed>"
    offset = passage.offset if passage.offset is not None else "<unknown>"
    return (
        f"filename={source} document={document_name} "
        f"passage_offset={offset} sequence_location={location}"
    )


@dataclass(frozen=True)
class _Pair:
    short_form: str
    long_form: str
    passage_index: int


@dataclass(frozen=True)
class _Match:
    next_index: int
    pairs: tuple[_Pair, ...]


@dataclass(frozen=True)
class _ParseResult:
    match: _Match | None
    reason: str | None = None


class _PassageParser:
    """Recursive-descent parser for the three supported passage patterns."""

    def __init__(self, passages: Sequence[bioc.BioCPassage]):
        self.passages = passages

    def parse_section(self, index: int) -> _ParseResult:
        """Parse one section or explain the failed expectation."""
        if not self._matches(index, "ABBR", _TITLE_TYPES):
            return _ParseResult(
                None,
                "expected section_type='ABBR' and type='title' or 'title_1'; "
                f"observed {_describe_passage(self.passages, index)}",
            )

        next_index = index + 1
        if self._matches(next_index, "TABLE", {"table"}):
            return self._parse_table(index)
        if self._matches(next_index, "ABBR", {"paragraph", "footnote"}):
            return self._parse_text(index)
        return _ParseResult(
            None,
            "expected an ABBR/paragraph (patterns #1 or #2) or "
            "TABLE/table (pattern #3) immediately after the title; "
            f"observed {_describe_passage(self.passages, next_index)}",
        )

    def _parse_table(self, index: int) -> _ParseResult:
        table_index = index + 1
        pairs, failure = _parse_table_xml(
            (self.passages[table_index].infons or {}).get("xml")
        )
        if pairs is None:
            return _ParseResult(None, failure)

        next_index = table_index + 1
        if next_index < len(self.passages) and _is_boilerplate(
            self.passages[next_index]
        ):
            next_index += 1
        # This exception is deliberately only ``title``, not ``title_1``.
        if self._matches(next_index, "ABBR", {"title"}):
            next_index += 1
        # Source tables can carry link/reference notes as ABBR footnotes.
        _, next_index = self._parse_footnotes(next_index)
        return _ParseResult(
            _Match(
                next_index,
                tuple(_Pair(sf, lf, table_index) for sf, lf in pairs),
            )
        )

    def _parse_text(self, index: int) -> _ParseResult:
        if self._matches(index + 1, "ABBR", {"footnote"}):
            return self._parse_footnote_definitions(index)

        paragraph_indexes, next_index = self._parse_paragraphs(index + 1)
        if paragraph_indexes and _is_boilerplate(self.passages[paragraph_indexes[0]]):
            paragraph_indexes = paragraph_indexes[1:]
        paragraph_indexes, narrative_indexes = self._split_narrative_trailer(
            paragraph_indexes
        )
        footnote_indexes, end_index = self._parse_footnotes(next_index)
        if not self._is_section_end(end_index):
            return _ParseResult(
                None,
                "expected the paragraph sequence to end, or to be followed only "
                "by trailing ABBR/footnote passages; "
                f"observed {_describe_passage(self.passages, end_index)}",
            )

        if not paragraph_indexes:
            return _ParseResult(
                None,
                "expected at least one abbreviation definition after optional "
                "boilerplate; observed no definition paragraphs",
            )

        if len(paragraph_indexes) == 1:
            # Pattern #2 has no footnotes.
            if footnote_indexes:
                return _ParseResult(
                    None,
                    "expected pattern #2 to end after its single ABBR/paragraph; "
                    f"observed {len(footnote_indexes)} trailing ABBR/footnote "
                    "passage(s), which are allowed only for pattern #1",
                )
            definitions, failure = _parse_definitions(
                _text(self.passages[paragraph_indexes[0]])
            )
            if definitions is None:
                return _ParseResult(None, failure)
            return _ParseResult(
                _Match(
                    end_index,
                    tuple(
                        _Pair(sf, lf, paragraph_indexes[0])
                        for sf, lf in definitions
                    ),
                ),
            )

        # Pattern #1 requires an even number of at least two paragraphs.
        if len(paragraph_indexes) % 2:
            return _ParseResult(
                None,
                "expected pattern #1 to contain an even number of at least two "
                f"ABBR/paragraph passages; observed {len(paragraph_indexes)}",
            )
        pairs = tuple(
            _Pair(
                _text(self.passages[paragraph_indexes[pair_index]]).strip(),
                _text(self.passages[paragraph_indexes[pair_index + 1]]).strip(),
                paragraph_indexes[pair_index],
            )
            for pair_index in range(0, len(paragraph_indexes), 2)
        )
        if narrative_indexes:
            end_index = narrative_indexes[-1] + 1
        return _ParseResult(_Match(end_index, pairs))

    def _parse_footnote_definitions(self, index: int) -> _ParseResult:
        footnote_indexes, end_index = self._parse_footnotes(index + 1)
        definitions, failure = _parse_definitions(
            _text(self.passages[footnote_indexes[0]])
        )
        if definitions is None:
            return _ParseResult(None, failure)
        return _ParseResult(
            _Match(
                end_index,
                tuple(
                    _Pair(sf, lf, footnote_indexes[0])
                    for sf, lf in definitions
                ),
            )
        )

    def _split_narrative_trailer(
        self, paragraph_indexes: tuple[int, ...]
    ) -> tuple[tuple[int, ...], tuple[int, ...]]:
        if len(paragraph_indexes) < 3:
            return paragraph_indexes, ()
        for position in range(0, len(paragraph_indexes), 2):
            if _is_narrative(self.passages[paragraph_indexes[position]]):
                trailer = paragraph_indexes[position:]
                if trailer and all(
                    _is_narrative(self.passages[item]) for item in trailer
                ):
                    return paragraph_indexes[:position], trailer
        return paragraph_indexes, ()

    def _parse_paragraphs(self, index: int) -> tuple[tuple[int, ...], int]:
        """paragraphs := paragraph paragraphs | empty"""
        if self._matches(index, "ABBR", {"paragraph"}):
            remaining, next_index = self._parse_paragraphs(index + 1)
            return (index, *remaining), next_index
        return (), index

    def _parse_footnotes(self, index: int) -> tuple[tuple[int, ...], int]:
        """footnotes := footnote footnotes | empty"""
        if self._matches(index, "ABBR", {"footnote"}):
            remaining, next_index = self._parse_footnotes(index + 1)
            return (index, *remaining), next_index
        return (), index

    def _is_section_end(self, index: int) -> bool:
        if index >= len(self.passages):
            return True
        passage = self.passages[index]
        return not _is_abbr(passage) or _is_title(passage)

    def _matches(
        self,
        index: int,
        section_type: str,
        passage_types: frozenset[str] | set[str],
    ) -> bool:
        if index >= len(self.passages):
            return False
        passage = self.passages[index]
        return (
            _section_type(passage) == section_type
            and _passage_type(passage) in passage_types
        )


def _describe_passage(
    passages: Sequence[bioc.BioCPassage], index: int
) -> str:
    if index >= len(passages):
        return "end of document"
    passage = passages[index]
    return (
        f"section_type={_section_type(passage)!r}, "
        f"type={_passage_type(passage)!r}, text={_text(passage)!r}"
    )


def _parse_definitions(
    text: str,
) -> tuple[tuple[tuple[str, str], ...] | None, str | None]:
    """Parse definitions using one delimiter shared by every pair.

    Candidate delimiters are tried in first-appearance order. Once selected,
    other supported delimiter characters are ordinary SF/LF text.
    """
    definitions = text.split(";")

    if any(not definition.strip() for definition in definitions):
        empty_index = next(
            index for index, definition in enumerate(definitions) if not definition.strip()
        )
        return None, (
            f"expected definition {empty_index + 1} to contain an SF/LF pair; "
            "observed an empty semicolon-delimited definition"
        )

    candidates: list[str] = []
    for character in text:
        if character in _PAIR_SEPARATORS and character not in candidates:
            candidates.append(character)

    delimiter = next(
        (
            candidate
            for candidate in candidates
            if all(
                candidate in definition
                and all(part.strip() for part in definition.split(candidate, 1))
                for definition in definitions
            )
        ),
        None,
    )
    if delimiter is None:
        parenthetical = _parse_parenthetical_definitions(definitions)
        if parenthetical is not None:
            return parenthetical, None
        candidate_text = ", ".join(repr(candidate) for candidate in candidates) or "none"
        return None, (
            "expected one common delimiter (',', ':', or '=') to occur in every "
            "definition and separate non-empty SF/LF values; "
            f"observed candidate delimiters {candidate_text} with no valid common delimiter"
        )

    def descend(
        index: int,
    ) -> tuple[tuple[tuple[str, str], ...] | None, str | None]:
        if index == len(definitions):
            return (), None
        definition = definitions[index].strip()
        short_form, long_form = (
            part.strip() for part in definition.split(delimiter, 1)
        )
        remaining, failure = descend(index + 1)
        if remaining is None:
            return None, failure
        return ((short_form, long_form), *remaining), None

    return descend(0)


def _parse_parenthetical_definitions(
    definitions: Sequence[str],
) -> tuple[tuple[str, str], ...] | None:
    """Parse the observed ``SF (LF); SF (LF)`` single-passage variant."""
    pattern = re.compile(r"^(.+?)\s+\((.+)\)\.?$")

    def descend(index: int) -> tuple[tuple[str, str], ...] | None:
        if index == len(definitions):
            return ()
        match = pattern.fullmatch(definitions[index].strip())
        if match is None:
            return None
        short_form, long_form = (part.strip() for part in match.groups())
        if not short_form or not long_form:
            return None
        remaining = descend(index + 1)
        if remaining is None:
            return None
        return ((short_form, long_form), *remaining)

    return descend(0)


def _local_name(name: str) -> str:
    return name.rsplit("}", 1)[-1]


def _parse_table_xml(
    value: object,
) -> tuple[tuple[tuple[str, str], ...] | None, str | None]:
    if not isinstance(value, str) or not value.strip():
        return None, "expected the table passage's 'xml' infon to contain XML; observed missing or empty XML"

    markup = value.strip()
    try:
        root = ET.fromstring(markup)
    except (ET.ParseError, ValueError):
        # A table fragment can contain several sibling rows and therefore need
        # a synthetic root before ElementTree can parse it.
        try:
            root = ET.fromstring(f"<table>{markup}</table>")
        except (ET.ParseError, ValueError) as error:
            return None, (
                "expected well-formed table XML or a well-formed row fragment; "
                f"observed parse error: {error}"
            )

    table = root if _local_name(root.tag) == "table" else next(
        (element for element in root.iter() if _local_name(element.tag) == "table"),
        None,
    )
    if table is None:
        # A single root such as <tbody> or <tr> is itself a valid fragment.
        if any(_local_name(element.tag) == "tr" for element in root.iter()):
            table = root
        else:
            return None, (
                "expected a <table> element or markup containing table rows; "
                "observed no <tr> elements"
            )

    for element in table.iter():
        for attribute, attribute_value in element.attrib.items():
            if _local_name(attribute).casefold() in {"rowspan", "colspan"}:
                if attribute_value.strip() != "1":
                    return None, (
                        f"expected {_local_name(attribute)} to be '1'; "
                        f"observed {attribute_value!r}"
                    )

    rows = [element for element in table.iter() if _local_name(element.tag) == "tr"]
    if not rows:
        return None, "expected at least one <tr> row; observed zero rows"

    pairs: list[tuple[str, str]] = []
    for row in rows:
        cells = [
            child
            for child in list(row)
            if _local_name(child.tag) in {"td", "th"}
        ]
        if len(cells) != 2:
            return None, (
                f"expected table row {len(pairs) + 1} to contain exactly two "
                f"cells; observed {len(cells)}"
            )
        short_form, long_form = (
            "".join(cell.itertext()).strip() for cell in cells
        )
        if not short_form or not long_form:
            empty_parts = []
            if not short_form:
                empty_parts.append("SF")
            if not long_form:
                empty_parts.append("LF")
            return None, (
                f"expected table row {len(pairs) + 1} to contain non-empty SF "
                "and LF cells; observed empty " + " and ".join(empty_parts)
            )
        pairs.append((short_form, long_form))
    return tuple(pairs), None


def _log_pair(
    filename: Path | str,
    document: bioc.BioCDocument,
    passages: Sequence[bioc.BioCPassage],
    pair: _Pair,
) -> None:
    passage = passages[pair.passage_index]
    LOG.info(
        '%s SF: "%s"; LF: "%s"',
        _context(filename, document, passage, pair.passage_index),
        pair.short_form,
        pair.long_form,
    )


def _warn_unrecognized(
    filename: Path | str,
    document: bioc.BioCDocument,
    passage: bioc.BioCPassage,
    index: int,
    reason: str,
) -> None:
    LOG.warning(
        '%s unrecognized ABBR passage: type=%r text=%r; mismatch: %s',
        _context(filename, document, passage, index),
        _passage_type(passage),
        _text(passage),
        reason,
    )


def detect_document(filename: Path | str, document: bioc.BioCDocument) -> int:
    """Detect pairs in one document, log them, and return their count."""
    passages = document.passages or []
    parser = _PassageParser(passages)
    pair_count = 0
    index = 0
    while index < len(passages):
        if _is_known_non_abbreviation_title(passages[index]):
            LOG.debug(
                "%s skipped known non-abbreviation section mislabeled ABBR",
                _context(filename, document, passages[index], index),
            )
            index += 1
            while index < len(passages) and _is_abbr(passages[index]) and not _is_title(
                passages[index]
            ):
                index += 1
            continue
        result = parser.parse_section(index)
        match = result.match
        if match is not None:
            for pair in match.pairs:
                _log_pair(filename, document, passages, pair)
            pair_count += len(match.pairs)
            index = match.next_index
            continue
        if _is_abbr(passages[index]):
            _warn_unrecognized(
                filename,
                document,
                passages[index],
                index,
                result.reason or "expected a recognized abbreviation pattern; observed no match",
            )
        index += 1
    return pair_count


def detect_collection(filename: Path | str, collection: bioc.BioCCollection) -> int:
    """Detect pairs in every document and return the collection total."""
    return sum(detect_document(filename, document) for document in collection.documents)


def _input_files(input_path: Path) -> list[Path]:
    if input_path.is_file():
        return [input_path]
    if input_path.is_dir():
        return sorted((*input_path.glob("*.xml"), *input_path.glob("*.xml.gz")))
    raise FileNotFoundError(f"Abbreviation input path does not exist: {input_path}")


def run(config_path: Path, overrides=None) -> int:
    """Process all configured inputs and return the total number of pairs."""
    config = load_config(config_path, overrides)
    pair_count = 0
    for input_file in _input_files(config.abbreviation_input):
        pair_count += detect_collection(input_file, load_collection(input_file))
    return pair_count


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/pipeline.yaml"))
    add_config_arguments(parser)
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    parser.add_argument("--log-file", type=Path)
    args = parser.parse_args()
    configure_logging(args.log_level, args.log_file)
    run(args.config, config_overrides(args))


if __name__ == "__main__":
    main()
