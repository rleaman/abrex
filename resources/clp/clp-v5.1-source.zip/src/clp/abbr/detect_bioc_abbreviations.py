"""Detect abbreviation pairs represented by BioC ``ABBR`` sections.

This detector reports pairs from the section convention used by the source
data.  It deliberately does not add annotations or modify the collection.
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
import bioc

from ..bioc_io import load_collection
from ..config import add_config_arguments, config_overrides, load_config
from ..logging_utils import configure_logging

LOG = logging.getLogger(__name__)


def _context(filename: Path | str, document: bioc.BioCDocument, passage: bioc.BioCPassage) -> str:
    """Return the required location context for a log record."""
    filename = Path(filename).name
    document_name = document.id or "<unnamed>"
    offset = passage.offset if passage.offset is not None else "<unknown>"
    return f"filename={filename} document={document_name} passage_offset={offset}"


def _section_type(passage: bioc.BioCPassage) -> object:
    return (passage.infons or {}).get("section_type")


def _passage_type(passage: bioc.BioCPassage) -> object:
    return (passage.infons or {}).get("type")


def _warn_ignored(filename: Path | str, document: bioc.BioCDocument, passage: bioc.BioCPassage, reason: str) -> None:
    LOG.warning("%s ignored ABBR passage: %s", _context(filename, document, passage), reason)


def _process_section(
    filename: Path | str,
    document: bioc.BioCDocument,
    section: list[bioc.BioCPassage],
) -> int:
    """Log pairs in one complete ABBR section and return its pair count."""
    paragraphs = [passage for passage in section if _passage_type(passage) == "paragraph"]
    if len(paragraphs) % 2:
        first = section[0]
        LOG.error(
            "%s ABBR section has an odd number of paragraph passages (%d)",
            _context(filename, document, first),
            len(paragraphs),
        )
        for passage in section:
            LOG.warning(
                "%s passage belongs to an ABBR section with an odd number of paragraphs",
                _context(filename, document, passage),
            )
        return 0

    for index in range(0, len(paragraphs), 2):
        short_form = paragraphs[index]
        long_form = paragraphs[index + 1]
        LOG.info(
            '%s SF: "%s"; LF: "%s" (LF %s)',
            _context(filename, document, short_form),
            short_form.text or "",
            long_form.text or "",
            _context(filename, document, long_form),
        )
    return len(paragraphs) // 2


def detect_document(filename: Path | str, document: bioc.BioCDocument) -> int:
    """Detect and log ABBR pairs in one document."""
    section: list[bioc.BioCPassage] = []
    pair_count = 0

    def finish_section() -> None:
        nonlocal section, pair_count
        if section:
            pair_count += _process_section(filename, document, section)
            section = []

    for passage in document.passages:
        is_abbr = _section_type(passage) == "ABBR"
        passage_type = _passage_type(passage)

        if section:
            if is_abbr:
                if passage_type == "paragraph":
                    section.append(passage)
                else:
                    _warn_ignored(filename, document, passage, "type is not paragraph")
                    section.append(passage)
                continue
            finish_section()

        if is_abbr:
            if passage_type == "title":
                section = [passage]
            else:
                _warn_ignored(filename, document, passage, "ABBR section does not start with a title")

    finish_section()
    return pair_count


def detect_collection(filename: Path | str, collection: bioc.BioCCollection) -> int:
    """Detect and log ABBR pairs in every document of a collection."""
    return sum(detect_document(filename, document) for document in collection.documents)


def _input_files(input_path: Path) -> list[Path]:
    if input_path.is_file():
        return [input_path]
    if input_path.is_dir():
        return sorted((*input_path.glob("*.xml"), *input_path.glob("*.xml.gz")))
    raise FileNotFoundError(f"Abbreviation input path does not exist: {input_path}")


def run(config_path: Path, overrides=None) -> None:
    config = load_config(config_path, overrides)
    for input_file in _input_files(config.abbreviation_input):
        collection = load_collection(input_file)
        detect_collection(input_file, collection)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/pipeline.yaml"))
    add_config_arguments(parser)
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--log-file", type=Path)
    args = parser.parse_args()
    configure_logging(args.log_level, args.log_file)
    run(args.config, config_overrides(args))


if __name__ == "__main__":
    main()
