"""Exploratory parser for abbreviation sections in BioC XML collections.

Structural parsing and SF/LF interpretation are deliberately separate.  The
parser retains competing candidates, failures, warnings, and score components
so corpus behavior can be inspected before production rules are selected.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from enum import Enum
import gzip
import json
import logging
import math
from pathlib import Path
import random
import re
from statistics import mean
from typing import Any, Iterable, Mapping, Sequence
import xml.etree.ElementTree as ET

import bioc

from ..bioc_io import load_collection
from ..config import add_config_arguments, config_overrides, load_config
from ..logging_utils import configure_logging

LOG = logging.getLogger(__name__)
TITLE_TYPES = frozenset({"title", "title_1"})
DELIMITERS = (":", "=", ",")
BOILERPLATE = "the following abbreviations are used in this manuscript"
NON_ABBREVIATION_TITLES = frozenset({"citations", "consent for publication"})
PARENTHETICAL = re.compile(r"^\s*(.+?)\s*\(([^()]*)\)\s*\.?\s*$")
WORD = re.compile(r"[A-Za-z]+(?:[-'][A-Za-z]+)*")
CITATION = re.compile(r"(?:\[[0-9,\- ]+\]|\([A-Z][A-Za-z]+ et al\.,? \d{4}\))")


class Orientation(str, Enum):
    FIRST_IS_SF = "FIRST_IS_SF"
    SECOND_IS_SF = "SECOND_IS_SF"
    UNKNOWN = "UNKNOWN"


class SequenceClassification(str, Enum):
    CLEAR_KNOWN_PATTERN = "CLEAR_KNOWN_PATTERN"
    AMBIGUOUS_KNOWN_PATTERN = "AMBIGUOUS_KNOWN_PATTERN"
    KNOWN_PATTERN_WITH_WARNINGS = "KNOWN_PATTERN_WITH_WARNINGS"
    UNPARSED = "UNPARSED"


@dataclass(frozen=True)
class ScoreContribution:
    feature: str
    value: float
    detail: str = ""


@dataclass
class Pair:
    first: str
    second: str
    orientation: Orientation = Orientation.UNKNOWN
    orientation_evidence: list[str] = field(default_factory=list)
    source_passage_indexes: list[int] = field(default_factory=list)
    parser_pattern: str = ""
    parser_subpattern: str | None = None
    forward_count: int = 0
    reverse_count: int = 0
    prose_likelihood_first: float = 0.0
    prose_likelihood_second: float = 0.0
    # A production definition is unique within a document, but the audit trail
    # must retain every place where it appeared.  Older reports omit this field;
    # consumers should fall back to ``source_passage_indexes`` in that case.
    source_occurrences: list[list[int]] = field(default_factory=list)

    @property
    def short_form(self) -> str | None:
        if self.orientation == Orientation.FIRST_IS_SF:
            return self.first
        if self.orientation == Orientation.SECOND_IS_SF:
            return self.second
        return None

    @property
    def long_form(self) -> str | None:
        if self.orientation == Orientation.FIRST_IS_SF:
            return self.second
        if self.orientation == Orientation.SECOND_IS_SF:
            return self.first
        return None


@dataclass
class ParseCandidate:
    pattern: str
    subpattern: str | None
    start_index: int
    end_index: int
    pairs: list[Pair]
    score: float = 0.0
    warnings: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    unconsumed_abbr_passages: list[int] = field(default_factory=list)
    score_contributions: list[ScoreContribution] = field(default_factory=list)
    diagnostics: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ParseFailure:
    pattern: str
    reason: str
    passage_indexes: tuple[int, ...] = ()
    diagnostics: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class SequenceAnalysis:
    filename: str
    document_id: str
    identifiers: dict[str, str]
    title_text: str
    start_index: int
    classification: SequenceClassification
    candidates: list[ParseCandidate]
    failures: list[ParseFailure]
    best_candidate: ParseCandidate | None
    score_margin: float | None
    source_passages: list[dict[str, Any]]


@dataclass
class CorpusReport:
    sequences: list[SequenceAnalysis] = field(default_factory=list)
    number_of_articles: int = 0

    def summary(self) -> dict[str, Any]:
        classes = Counter(x.classification.value for x in self.sequences)
        patterns = Counter(x.best_candidate.pattern for x in self.sequences if x.best_candidate)
        subpatterns = Counter(f"{x.best_candidate.pattern}/{x.best_candidate.subpattern}"
                              for x in self.sequences if x.best_candidate)
        per_pattern = {}
        for pattern in sorted(patterns):
            candidates = [x.best_candidate for x in self.sequences
                          if x.best_candidate and x.best_candidate.pattern == pattern]
            per_pattern[pattern] = {
                "number_of_sequences": len(candidates),
                "number_of_extracted_pairs": sum(len(x.pairs) for x in candidates),
                "pairs_per_sequence": _distribution(len(x.pairs) for x in candidates),
                "consumed_passages": _distribution(x.end_index - x.start_index for x in candidates),
                "warning_counts": dict(Counter(w for x in candidates for w in x.warnings)),
            }
        overruns, orientation = [], Counter()
        for sequence in self.sequences:
            candidate = sequence.best_candidate
            if not candidate:
                continue
            passages = {x["index"]: x for x in sequence.source_passages}
            for index in candidate.unconsumed_abbr_passages:
                if index in passages:
                    text = passages[index]["text"]
                    overruns.append((passages[index]["type"], len(text), len(text.split()),
                                     len(candidate.unconsumed_abbr_passages)))
            for pair in candidate.pairs:
                if pair.forward_count and pair.reverse_count:
                    orientation["dictionary_both"] += 1
                elif pair.forward_count:
                    orientation["dictionary_agrees"] += 1
                elif pair.reverse_count:
                    orientation["dictionary_reverses"] += 1
                else:
                    orientation["dictionary_unknown"] += 1
                if "SHAPE_AGREES" in pair.orientation_evidence:
                    orientation["shape_agrees"] += 1
                elif "SHAPE_DISAGREES" in pair.orientation_evidence:
                    orientation["shape_disagrees"] += 1
                else:
                    orientation["shape_unknown"] += 1
        pattern_1_pairs = [pair for sequence in self.sequences
                           if sequence.best_candidate and sequence.best_candidate.pattern == "PATTERN_1"
                           for pair in sequence.best_candidate.pairs]
        return {
            "number_of_articles": self.number_of_articles,
            "number_of_abbr_starts": len(self.sequences),
            "number_parsed_by_pattern": dict(sorted(patterns.items())),
            "number_parsed_by_pattern_subpattern": dict(sorted(subpatterns.items())),
            "number_ambiguous": classes[SequenceClassification.AMBIGUOUS_KNOWN_PATTERN.value],
            "number_with_warnings": classes[SequenceClassification.KNOWN_PATTERN_WITH_WARNINGS.value],
            "number_unparsed": classes[SequenceClassification.UNPARSED.value],
            "classifications": dict(sorted(classes.items())), "patterns": per_pattern,
            "abbr_overrun": {
                "number_of_passages": len(overruns),
                "passage_types": dict(Counter(x[0] for x in overruns)),
                "text_lengths": _distribution(x[1] for x in overruns),
                "token_lengths": _distribution(x[2] for x in overruns),
                "passages_after_endpoint": _distribution(x[3] for x in overruns),
            },
            "orientation_evidence": dict(sorted(orientation.items())),
            "pattern_1_endpoint_features": {
                "candidate_sf_character_lengths": _distribution(len(x.first) for x in pattern_1_pairs),
                "candidate_lf_character_lengths": _distribution(len(x.second) for x in pattern_1_pairs),
                "candidate_sf_token_lengths": _distribution(len(x.first.split()) for x in pattern_1_pairs),
                "candidate_lf_token_lengths": _distribution(len(x.second.split()) for x in pattern_1_pairs),
                "sf_prose_likelihood_histogram": dict(sorted(Counter(x.prose_likelihood_first for x in pattern_1_pairs).items())),
                "lf_prose_likelihood_histogram": dict(sorted(Counter(x.prose_likelihood_second for x in pattern_1_pairs).items())),
            },
        }


def _distribution(values: Iterable[int]) -> dict[str, Any]:
    values = list(values)
    if not values:
        return {"count": 0, "histogram": {}}
    return {"count": len(values), "min": min(values), "max": max(values),
            "mean": mean(values), "histogram": dict(sorted(Counter(values).items()))}


def _section_type(passage):
    return (passage.infons or {}).get("section_type")


def _passage_type(passage):
    return (passage.infons or {}).get("type")


def _text(passage):
    return passage.text or ""


def _is_abbr(passage):
    return _section_type(passage) == "ABBR"


def _is_start(passage):
    return _is_abbr(passage) and _passage_type(passage) in TITLE_TYPES


def _is_boilerplate(passage):
    return " ".join(_text(passage).split()).strip(" .:").casefold() == BOILERPLATE


def _normalized_text(passage):
    return " ".join(_text(passage).split()).strip(" .:").casefold()


def prose_likelihood(text: str) -> float:
    """Return an inspectable 0..1 heuristic for ordinary prose."""
    clean = " ".join(text.split())
    if not clean:
        return 1.0
    tokens, words = clean.split(), WORD.findall(clean)
    clauses = len(re.findall(r"[.!?](?:\s|$)|[;:]\s", clean))
    abbrev = sum(bool(re.fullmatch(r"[A-Z0-9][A-Z0-9./+\-]{0,11}", x.strip("(),;:")))
                 for x in tokens)
    score = min(len(clean) / 500, .28) + min(len(tokens) / 60, .28)
    score += min(clauses / 5, .20) + (.12 if clean.endswith((".", "?", "!")) else 0)
    score += .12 if CITATION.search(clean) else 0
    score -= .15 if words and abbrev / max(len(tokens), 1) > .5 else 0
    return round(max(0., min(1., score)), 3)


def load_ab3p_dictionary(path: Path | str | None) -> dict[str, dict[str, int]]:
    """Load the optional diagnostic ``{SF: {LF: count}}`` resource."""
    if path is None:
        raise ValueError("Dictionary path may not be None")
    source = Path(path)
    opener = gzip.open if source.suffix == ".gz" else open
    with opener(source, "rt", encoding="utf-8") as stream:
        result = json.load(stream)
    if not isinstance(result, dict):
        raise ValueError("Ab3P dictionary must be a JSON object")
    return result


def _shape_score(value: str) -> float:
    tokens, compact = value.split(), re.sub(r"[^A-Za-z0-9]", "", value)
    score = 1. if len(tokens) == 1 else (-1. if len(tokens) >= 4 else 0.)
    score += .6 if compact and len(compact) <= 10 else 0
    score += .35 if any(x.isupper() for x in value) else 0
    score += .35 if re.fullmatch(r"[A-Za-z0-9./+\-]+", value.strip()) else 0
    return score


def _orient(pair: Pair, dictionary, structural=Orientation.UNKNOWN):
    pair.forward_count = int((dictionary or {}).get(pair.first, {}).get(pair.second, 0))
    pair.reverse_count = int((dictionary or {}).get(pair.second, {}).get(pair.first, 0))
    pair.orientation_evidence.append("KNOWN_BOTH" if pair.forward_count and pair.reverse_count
        else "KNOWN_FORWARD" if pair.forward_count else "KNOWN_REVERSE" if pair.reverse_count
        else "DICTIONARY_UNKNOWN")
    a, b = _shape_score(pair.first), _shape_score(pair.second)
    shape = Orientation.UNKNOWN
    if abs(a - b) >= .75:
        shape = Orientation.FIRST_IS_SF if a > b else Orientation.SECOND_IS_SF
        pair.orientation_evidence.append(f"SHAPE_{shape.value}")
    if structural != Orientation.UNKNOWN:
        pair.orientation = structural
        pair.orientation_evidence.append(f"STRUCTURAL_{structural.value}")
        pair.orientation_evidence.append("SHAPE_AGREES" if shape == structural else
                                         "SHAPE_DISAGREES" if shape != Orientation.UNKNOWN else "SHAPE_UNKNOWN")
        if pair.reverse_count > max(5, pair.forward_count * 3):
            pair.orientation_evidence.append("DICTIONARY_STRONGLY_REVERSES_STRUCTURE")
        elif pair.forward_count:
            pair.orientation_evidence.append("DICTIONARY_AGREES_WITH_STRUCTURE")
    elif pair.forward_count > max(2, pair.reverse_count * 2):
        pair.orientation, marker = Orientation.FIRST_IS_SF, "ORIENTED_BY_DICTIONARY"
        pair.orientation_evidence.append(marker)
    elif pair.reverse_count > max(2, pair.forward_count * 2):
        pair.orientation, marker = Orientation.SECOND_IS_SF, "ORIENTED_BY_DICTIONARY"
        pair.orientation_evidence.append(marker)
    elif shape != Orientation.UNKNOWN:
        pair.orientation = shape
        pair.orientation_evidence.append("ORIENTED_BY_SHAPE")


def _pair(a, b, indexes, pattern, subtype, dictionary, structural=Orientation.UNKNOWN):
    result = Pair(a.strip(), b.strip(), source_passage_indexes=indexes,
                  source_occurrences=[list(indexes)],
                  parser_pattern=pattern, parser_subpattern=subtype,
                  prose_likelihood_first=prose_likelihood(a), prose_likelihood_second=prose_likelihood(b))
    _orient(result, dictionary, structural)
    return result


def _add(candidate, feature, value, detail=""):
    candidate.score += value
    candidate.score_contributions.append(ScoreContribution(feature, value, detail))


def _following_abbr(passages, index):
    result = []
    while index < len(passages) and _is_abbr(passages[index]):
        result.append(index)
        index += 1
    return result


def _finish(candidate, passages):
    candidate.unconsumed_abbr_passages = _following_abbr(passages, candidate.end_index)
    if candidate.unconsumed_abbr_passages:
        candidate.warnings.append("ABBR_OVERRUN")
        _add(candidate, "abbr_overrun", -.35, str(len(candidate.unconsumed_abbr_passages)))
    _add(candidate, "valid_pairs", len(candidate.pairs) * 2., str(len(candidate.pairs)))
    for pair in candidate.pairs:
        likelihood = max(pair.prose_likelihood_first, pair.prose_likelihood_second)
        if likelihood >= .65:
            candidate.warnings.append("PROSE_LIKE_PAIR_MEMBER")
            _add(candidate, "prose_like_pair_member", -2 * likelihood, str(likelihood))
        if pair.forward_count:
            _add(candidate, "dictionary_forward", min(1.5, math.log1p(pair.forward_count) / 6))
        if "DICTIONARY_STRONGLY_REVERSES_STRUCTURE" in pair.orientation_evidence:
            _add(candidate, "dictionary_reverses_structure", -1.25)
    candidate.warnings = list(dict.fromkeys(candidate.warnings))
    return candidate


def _paragraph_run(passages, index):
    result = []
    while index < len(passages) and _is_abbr(passages[index]) and _passage_type(passages[index]) == "paragraph":
        result.append(index)
        index += 1
    return result


def _pattern1(passages, start, dictionary):
    indexes = _paragraph_run(passages, start + 1)
    if indexes and _is_boilerplate(passages[indexes[0]]):
        indexes = indexes[1:]
    usable = []
    for index in indexes:
        if len(usable) >= 2 and len(usable) % 2 == 0 and prose_likelihood(_text(passages[index])) >= .68:
            break
        usable.append(index)
    if len(usable) < 2:
        next_index = start + 1 + len(indexes)
        if indexes and next_index < len(passages) and _is_abbr(passages[next_index]):
            reason = ("expected the paragraph sequence to end, or to be followed only "
                      "by trailing ABBR/footnote passages; observed an interrupted sequence")
        else:
            reason = "expected at least two ABBR paragraph passages"
        return [], ParseFailure("PATTERN_1", reason, tuple(indexes))
    complete = len(usable) - len(usable) % 2
    pairs = [_pair(_text(passages[usable[i]]), _text(passages[usable[i + 1]]), [usable[i], usable[i + 1]],
                   "PATTERN_1", "ALTERNATING", dictionary, Orientation.FIRST_IS_SF)
             for i in range(0, complete, 2)]
    candidate = ParseCandidate("PATTERN_1", "ALTERNATING", start, usable[complete - 1] + 1, pairs)
    _add(candidate, "expected_passage_types", 2.); _add(candidate, "complete_alternation", 1.5)
    if len(usable) % 2:
        candidate.warnings.append("ODD_UNMATCHED_PARAGRAPH")
        candidate.diagnostics["unmatched_passage"] = usable[-1]
        _add(candidate, "odd_unmatched_passage", -1.25)
    candidate.diagnostics.update({"candidate_sf_lengths": [len(x.first) for x in pairs],
        "candidate_lf_lengths": [len(x.second) for x in pairs],
        "prose_likelihoods": [[x.prose_likelihood_first, x.prose_likelihood_second] for x in pairs]})
    return [_finish(candidate, passages)], None


def _delimiter_entries(text, delimiter):
    pairs, malformed = [], []
    for number, raw in enumerate(text.split(";"), 1):
        if delimiter not in raw:
            malformed.append(number); continue
        a, b = (x.strip() for x in raw.split(delimiter, 1))
        if a and b: pairs.append((a, b))
        else: malformed.append(number)
    return pairs, malformed


def _pattern2(passages, start, dictionary):
    index = start + 1
    if index >= len(passages) or not _is_abbr(passages[index]) or _passage_type(passages[index]) not in {"paragraph", "footnote"}:
        return [], ParseFailure("PATTERN_2", "expected one ABBR paragraph containing delimited definitions", (index,))
    text, candidates = _text(passages[index]), []
    definitions = text.split(";")
    for delimiter in DELIMITERS:
        parsed, malformed = _delimiter_entries(text, delimiter)
        if malformed or not parsed:
            continue
        subtype = f"DELIMITER_{delimiter}"
        candidate = ParseCandidate("PATTERN_2", subtype, start, index + 1,
            [_pair(a, b, [index], "PATTERN_2", subtype, dictionary, Orientation.FIRST_IS_SF) for a, b in parsed],
            diagnostics={"delimiter": delimiter, "number_of_definitions": len(definitions), "malformed_entries": []})
        _add(candidate, "consistent_delimiter", 2.); _add(candidate, "all_entries_parsed", 1.)
        if len(definitions) == 1:
            candidate.warnings.append("SINGLE_DEFINITION_PATTERN_2"); _add(candidate, "single_definition", -1.)
        candidates.append(_finish(candidate, passages))
    if _passage_type(passages[index]) == "footnote":
        parsed = []
        for raw in definitions:
            match = PARENTHETICAL.fullmatch(raw)
            if not match or not all(x.strip() for x in match.groups()):
                parsed = []; break
            parsed.append(tuple(x.strip() for x in match.groups()))
        if parsed:
            subtype = "FOOTNOTE_PARENTHETICAL"
            candidate = ParseCandidate("PATTERN_2", subtype, start, index + 1,
                [_pair(a, b, [index], "PATTERN_2", subtype, dictionary, Orientation.FIRST_IS_SF) for a, b in parsed])
            candidate.evidence.append("observed historical footnote variant")
            _add(candidate, "consistent_parenthetical_entries", 2.)
            candidates.append(_finish(candidate, passages))
    if not candidates:
        observed = [delimiter for delimiter in DELIMITERS if delimiter in text]
        observed_text = ", ".join(repr(x) for x in observed) if observed else "none"
        reason = ("expected one common delimiter (',', ':', or '=') across all definitions; "
                  f"observed candidate delimiters {observed_text} with no valid common delimiter")
        return [], ParseFailure("PATTERN_2", reason, (index,),
            {x: _delimiter_entries(text, x)[1] for x in DELIMITERS})
    if len(candidates) > 1:
        for candidate in candidates:
            candidate.warnings.append("COMPETING_DELIMITER_INTERPRETATIONS")
            candidate.diagnostics["competing_delimiters"] = [x.subpattern for x in candidates if x is not candidate]
    return candidates, None


def _local_name(name):
    return name.rsplit("}", 1)[-1].casefold()


def _table_cell_text(cell):
    """Flatten inline table markup without retaining XML indentation."""
    parts = []
    for value in cell.itertext():
        parts.append(value.strip() if "\n" in value or "\r" in value else value)
    return " ".join("".join(parts).split())


def _table_data(value):
    diagnostic = {"synthetic_root_added": False, "tags_encountered": [], "rows": 0,
        "valid_rows": 0, "malformed_rows": [], "rowspan_present": False, "colspan_present": False}
    if not isinstance(value, str) or not value.strip():
        return diagnostic, "expected non-empty XML in the table passage's xml infon"
    try:
        root = ET.fromstring(value.strip())
    except (ET.ParseError, ValueError):
        try:
            fragment = re.sub(r"^\s*<\?xml[^>]*\?>", "", value).strip()
            root = ET.fromstring(f"<synthetic-root>{fragment}</synthetic-root>")
            diagnostic["synthetic_root_added"] = True
        except (ET.ParseError, ValueError) as error:
            return diagnostic, f"table XML parse error: {error}"
    diagnostic["tags_encountered"] = sorted({_local_name(x.tag) for x in root.iter()})
    rows = [x for x in root.iter() if _local_name(x.tag) == "tr"]
    diagnostic["rows"] = len(rows)
    if not rows: return diagnostic, "expected at least one table row; observed zero"
    for element in root.iter():
        for name, value in element.attrib.items():
            local = _local_name(name)
            if local in {"rowspan", "colspan"}:
                diagnostic[f"{local}_present"] = True
                try: effective = int(value.strip())
                except ValueError: effective = 2
                if effective > 1:
                    diagnostic["malformed_rows"].append(
                        {"reason": f"effective {local} > 1", "value": value})
                    return diagnostic, f"expected {local} to be '1'; observed {value!r}"
    pairs = []
    for number, row in enumerate(rows, 1):
        cells = [x for x in list(row) if _local_name(x.tag) in {"td", "th"}]
        if len(cells) != 2:
            diagnostic["malformed_rows"].append({"row": number, "reason": "expected exactly two cells", "cells": len(cells)})
            continue
        values = [_table_cell_text(x) for x in cells]
        if not all(values):
            diagnostic["malformed_rows"].append({"row": number, "reason": "empty cell"}); continue
        pairs.append(values)
    diagnostic["valid_rows"], diagnostic["pairs"] = len(pairs), pairs
    return (diagnostic, None) if pairs else (diagnostic, "table contained no valid two-cell, non-empty rows")


def _pattern3(passages, start, dictionary):
    index = start + 1
    leading_boilerplate = []
    while (
        index < len(passages)
        and _is_abbr(passages[index])
        and _is_boilerplate(passages[index])
    ):
        leading_boilerplate.append(index)
        index += 1
    if index >= len(passages) or _section_type(passages[index]) != "TABLE" or _passage_type(passages[index]) != "table":
        return [], ParseFailure("PATTERN_3", "expected a TABLE/table passage immediately after the title", (index,))
    diagnostic, error = _table_data((passages[index].infons or {}).get("xml"))
    if error: return [], ParseFailure("PATTERN_3", error, (index,), diagnostic)
    end = index + 1
    table_continuations = []
    while (
        end < len(passages)
        and _section_type(passages[end]) == "TABLE"
        and _passage_type(passages[end]) == "table"
    ):
        table_continuations.append(end)
        end += 1
    if end < len(passages) and _is_start(passages[end]) and _passage_type(passages[end]) == "title":
        end += 1; diagnostic["ignored_trailing_title"] = True
    if end < len(passages) and _is_boilerplate(passages[end]):
        end += 1; diagnostic["ignored_trailing_boilerplate"] = True
    while end < len(passages) and _is_abbr(passages[end]) and _passage_type(passages[end]) == "footnote": end += 1
    raw_pairs = diagnostic.pop("pairs")

    def source_indexes(first, second):
        for continuation in table_continuations:
            text = " ".join(_text(passages[continuation]).split()).casefold()
            if (
                " ".join(first.split()).casefold() in text
                and " ".join(second.split()).casefold() in text
            ):
                return [continuation]
        return [index]

    pairs = [_pair(a, b, source_indexes(a, b), "PATTERN_3", "TWO_COLUMN_TABLE", dictionary, Orientation.FIRST_IS_SF)
             for a, b in raw_pairs]
    if leading_boilerplate:
        diagnostic["ignored_leading_boilerplate"] = leading_boilerplate
    if table_continuations:
        diagnostic["table_continuation_passages"] = table_continuations
    candidate = ParseCandidate("PATTERN_3", "TWO_COLUMN_TABLE", start, end, pairs, diagnostics=diagnostic)
    _add(candidate, "table_passage", 2.); _add(candidate, "valid_two_column_table", 2.)
    if diagnostic["malformed_rows"]:
        candidate.warnings.append("MALFORMED_TABLE_ROWS")
        _add(candidate, "malformed_table_rows", -.75 * len(diagnostic["malformed_rows"]))
    return [_finish(candidate, passages)], None


def _pattern4(passages, start, dictionary):
    indexes = _paragraph_run(passages, start + 1)
    if indexes and _is_boilerplate(passages[indexes[0]]): indexes = indexes[1:]
    pairs, subtypes, alternatives = [], [], {}
    for index in indexes:
        text, splits = _text(passages[index]), []
        definitions = [item.strip() for item in text.split(";") if item.strip()]
        parenthetical = []
        for definition in definitions:
            match = PARENTHETICAL.fullmatch(definition)
            if not match or not all(x.strip() for x in match.groups()):
                parenthetical = []
                break
            parenthetical.append(
                (match.group(1).strip(), match.group(2).strip(), "PARENTHETICAL")
            )
        if parenthetical:
            splits = parenthetical
        elif ";" not in text:
            for position, char in enumerate(text):
                if char == "," and text[:position].strip() and text[position + 1:].strip():
                    splits.append((text[:position].strip(), text[position + 1:].strip(), "COMMA"))
        if not splits: break
        for a, b, subtype in splits:
            pairs.append(_pair(a, b, [index], "PATTERN_4", subtype, dictionary))
            subtypes.append(subtype)
        if len(splits) > 1 and not parenthetical:
            alternatives[index] = [
                {"first": a, "second": b} for a, b, _ in splits[1:]
            ]
    if not pairs:
        return [], ParseFailure("PATTERN_4", "first abbreviation paragraph did not match X (Y) or X, Y", tuple(indexes[:1]))
    subtype = subtypes[0] if len(set(subtypes)) == 1 else "MIXED"
    candidate = ParseCandidate("PATTERN_4", subtype, start, pairs[-1].source_passage_indexes[0] + 1, pairs)
    _add(candidate, "independently_parsed_paragraphs", 2.)
    if len(pairs) > len(indexes):
        candidate.evidence.append("semicolon-separated parenthetical definitions")
        candidate.diagnostics["parenthetical_definitions_in_single_passage"] = len(
            pairs
        )
    if alternatives:
        candidate.warnings.append("AMBIGUOUS_COMMA_SPLIT")
        candidate.diagnostics["alternative_comma_splits"] = alternatives
        _add(candidate, "ambiguous_comma_split", -.5)
    return [_finish(candidate, passages)], None


PARSERS = (_pattern1, _pattern2, _pattern3, _pattern4)


def _snapshot(passages, indexes):
    result = []
    for index in sorted(set(x for x in indexes if 0 <= x < len(passages))):
        passage, infons = passages[index], dict(passages[index].infons or {})
        if isinstance(infons.get("xml"), str) and len(infons["xml"]) > 500:
            infons["xml"] = infons["xml"][:500] + "..."
        result.append({"index": index, "offset": passage.offset, "section_type": _section_type(passage),
                       "type": _passage_type(passage), "text": _text(passage), "infons": infons})
    return result


def analyze_section(filename: Path | str, document: bioc.BioCDocument, start_index: int,
                    dictionary: Mapping[str, Mapping[str, int]] | None = None,
                    ambiguity_margin: float = 1.) -> SequenceAnalysis:
    passages = document.passages or []
    if start_index >= len(passages) or not _is_start(passages[start_index]):
        raise ValueError("start_index must identify an ABBR title/title_1 passage")
    candidates, failures = [], []
    for parser in PARSERS:
        parsed, failure = parser(passages, start_index, dictionary)
        candidates.extend(parsed)
        if failure: failures.append(failure)
    candidates.sort(key=lambda x: (-x.score, x.pattern, x.subpattern or ""))
    best = candidates[0] if candidates else None
    margin = candidates[0].score - candidates[1].score if len(candidates) > 1 else None
    classification = (SequenceClassification.UNPARSED if not candidates else
        SequenceClassification.AMBIGUOUS_KNOWN_PATTERN if margin is not None and margin <= ambiguity_margin else
        SequenceClassification.KNOWN_PATTERN_WITH_WARNINGS if best and best.warnings else
        SequenceClassification.CLEAR_KNOWN_PATTERN)
    relevant = {start_index}
    for candidate in candidates:
        relevant.update(range(start_index, candidate.end_index)); relevant.update(candidate.unconsumed_abbr_passages)
    if not candidates:
        relevant.update(_following_abbr(passages, start_index))
        if start_index + 1 < len(passages) and _section_type(passages[start_index + 1]) == "TABLE": relevant.add(start_index + 1)
    document_infons = dict(getattr(document, "infons", None) or {})
    identifiers = {"document_id": document.id or "<unnamed>"}
    identifiers.update({str(key): str(value) for key, value in document_infons.items()
                        if any(marker in str(key).casefold() for marker in ("pmid", "pmcid", "article-id"))})
    return SequenceAnalysis(Path(filename).name, document.id or "<unnamed>", identifiers, _text(passages[start_index]),
        start_index, classification, candidates, failures, best, margin, _snapshot(passages, relevant))


def analyze_document(filename, document, dictionary=None, ambiguity_margin=1.):
    """Analyze ABBR starts, honoring artifacts explicitly consumed by a parse."""
    passages, result, index = document.passages or [], [], 0
    while index < len(passages):
        if not _is_start(passages[index]):
            index += 1
            continue
        analysis = analyze_section(filename, document, index, dictionary, ambiguity_margin)
        result.append(analysis)
        # A Pattern 3 trailing ``title`` artifact is not another section start.
        if analysis.best_candidate and analysis.best_candidate.pattern == "PATTERN_3":
            index = max(index + 1, analysis.best_candidate.end_index)
        else:
            index += 1
    return result


def analyze_collection(filename, collection, dictionary=None, ambiguity_margin=1.):
    report = CorpusReport(number_of_articles=len(collection.documents))
    for document in collection.documents:
        report.sequences.extend(analyze_document(filename, document, dictionary, ambiguity_margin))
    return report


def _jsonable(value):
    if isinstance(value, Enum): return value.value
    if hasattr(value, "__dataclass_fields__"): return _jsonable(asdict(value))
    if isinstance(value, dict): return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [_jsonable(x) for x in value]
    return value


def write_report(report: CorpusReport, output_dir: Path | str, seed=17, sample_size=30):
    target, rng = Path(output_dir), random.Random(seed)
    samples = target / "samples"; samples.mkdir(parents=True, exist_ok=True)
    (target / "summary.json").write_text(json.dumps(report.summary(), indent=2), encoding="utf-8")
    with (target / "sequences.jsonl").open("w", encoding="utf-8") as stream:
        for sequence in report.sequences: stream.write(json.dumps(_jsonable(sequence), ensure_ascii=False) + "\n")
    groups = defaultdict(list)
    for sequence in report.sequences:
        best = sequence.best_candidate
        if best and not best.warnings: groups[f"clean_{best.pattern}_{best.subpattern}"].append(sequence)
        if best and best.pattern == "PATTERN_1":
            groups["pattern_1_long_sf"].append(sequence); groups["pattern_1_long_lf"].append(sequence)
        if best and any("DICTIONARY_STRONGLY_REVERSES_STRUCTURE" in p.orientation_evidence for p in best.pairs):
            groups["dictionary_reverse"].append(sequence)
        if sequence.classification == SequenceClassification.UNPARSED: groups["unparsed_random"].append(sequence)
        if sequence.classification == SequenceClassification.AMBIGUOUS_KNOWN_PATTERN: groups["ambiguous_low_margin"].append(sequence)
        if best and best.warnings: groups["highest_warning"].append(sequence)
    # At least one complete example for every failure reason.
    for number, reason in enumerate(sorted({f.reason for s in report.sequences for f in s.failures})):
        groups[f"failure_{number:03d}"] = [next(s for s in report.sequences if any(f.reason == reason for f in s.failures))]
    for name, items in groups.items():
        if name == "highest_warning": chosen = sorted(items, key=lambda x: len(x.best_candidate.warnings), reverse=True)[:sample_size]
        elif name == "ambiguous_low_margin": chosen = sorted(items, key=lambda x: x.score_margin)[:sample_size]
        elif name.startswith("pattern_1_long_"):
            attr = "first" if name.endswith("sf") else "second"
            chosen = sorted(items, key=lambda x: max(len(getattr(p, attr)) for p in x.best_candidate.pairs), reverse=True)[:sample_size]
        else: chosen = rng.sample(items, min(sample_size, len(items)))
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)[:100]
        (samples / f"{safe}.json").write_text(json.dumps([_jsonable(x) for x in chosen], ensure_ascii=False, indent=2), encoding="utf-8")


def _context(filename, document, passage, index):
    return (f"filename={Path(filename).name} document={document.id or '<unnamed>'} "
            f"passage_offset={passage.offset if passage.offset is not None else '<unknown>'} sequence_location={index}")


def detect_document(filename, document, dictionary=None):
    """Legacy facade: log the best parse's pairs and return their count."""
    total = 0
    for analysis in analyze_document(filename, document, dictionary):
        if _normalized_text(document.passages[analysis.start_index]) in NON_ABBREVIATION_TITLES:
            continue
        best = analysis.best_candidate
        if best:
            for pair in best.pairs:
                index = pair.source_passage_indexes[0]
                LOG.info('%s SF: "%s"; LF: "%s"', _context(filename, document, document.passages[index], index),
                         pair.short_form or pair.first, pair.long_form or pair.second)
            total += len(best.pairs)
        else:
            reason = "; ".join(f"{x.pattern}: {x.reason}" for x in analysis.failures)
            for item in analysis.source_passages:
                passage = document.passages[item["index"]]
                if _is_abbr(passage):
                    LOG.warning("%s unrecognized ABBR passage: type=%r text=%r; mismatch: expected a recognized abbreviation pattern; observed %s",
                        _context(filename, document, passage, item["index"]), _passage_type(passage), _text(passage), reason)
    return total


def detect_collection(filename, collection, dictionary=None):
    return sum(detect_document(filename, x, dictionary) for x in collection.documents)


def _input_files(path):
    if path.is_file(): return [path]
    if path.is_dir(): return sorted((*path.glob("*.xml"), *path.glob("*.xml.gz")))
    raise FileNotFoundError(f"Abbreviation input path does not exist: {path}")


def run(config_path, overrides=None, *, report_dir=None, dictionary_path=None, seed=17, sample_size=30):
    config = load_config(config_path, overrides)
    if dictionary_path is None:
        LOG.info("Ab3P dictionary disabled")
        dictionary = None
    else:
        LOG.info("Loading Ab3P dictionary: %s", dictionary_path)
        dictionary = load_ab3p_dictionary(dictionary_path)
        LOG.info("Loaded Ab3P dictionary: %s (%d short forms)", dictionary_path, len(dictionary))

    sources = _input_files(config.abbreviation_input)
    LOG.info("Found %d BioC input file(s) under %s", len(sources), config.abbreviation_input)
    if not sources:
        LOG.warning("No BioC input files found under %s", config.abbreviation_input)

    combined, total = CorpusReport(), 0
    successful: list[Path] = []
    failed: list[tuple[Path, Exception]] = []
    for number, source in enumerate(sources, 1):
        LOG.info("Processing BioC input file %d/%d: %s", number, len(sources), source)
        try:
            report = analyze_collection(source, load_collection(source), dictionary)
        except Exception as error:
            failed.append((source, error))
            LOG.exception("Failed BioC input file %d/%d: %s", number, len(sources), source)
            continue

        file_pairs = sum(len(x.best_candidate.pairs) for x in report.sequences if x.best_candidate)
        file_unparsed = sum(x.classification == SequenceClassification.UNPARSED for x in report.sequences)
        combined.number_of_articles += report.number_of_articles
        combined.sequences.extend(report.sequences)
        total += file_pairs
        successful.append(source)
        LOG.info(
            "Completed BioC input file %d/%d: %s; articles=%d abbr_starts=%d "
            "parsed=%d unparsed=%d pairs=%d",
            number, len(sources), source, report.number_of_articles, len(report.sequences),
            len(report.sequences) - file_unparsed, file_unparsed, file_pairs,
        )

    LOG.info("BioC input summary: total=%d successful=%d failed=%d",
             len(sources), len(successful), len(failed))
    for source in successful:
        LOG.info("Successful BioC input file: %s", source)
    for source, error in failed:
        LOG.error("Failed BioC input file: %s; %s: %s", source, type(error).__name__, error)
    LOG.info("Corpus summary: articles=%d abbr_starts=%d pairs=%d",
             combined.number_of_articles, len(combined.sequences), total)

    if report_dir is not None:
        LOG.info("Writing exploration report from %d successful input file(s) to %s",
                 len(successful), report_dir)
        write_report(combined, report_dir, seed, sample_size)
        LOG.info("Completed exploration report: %s", report_dir)

    if failed:
        raise RuntimeError(
            f"{len(failed)} of {len(sources)} BioC input files failed; "
            "see the preceding log messages for file names and errors"
        )
    return total


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/pipeline.yaml")); add_config_arguments(parser)
    parser.add_argument("--dictionary", type=Path, help="optional Ab3P frequency JSON[.gz]")
    parser.add_argument("--report-dir", type=Path); parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--sample-size", type=int, default=30)
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--log-file", type=Path)
    args = parser.parse_args(); configure_logging(args.log_level, args.log_file)
    run(args.config, config_overrides(args), report_dir=args.report_dir, dictionary_path=args.dictionary,
        seed=args.seed, sample_size=args.sample_size)


if __name__ == "__main__": main()
