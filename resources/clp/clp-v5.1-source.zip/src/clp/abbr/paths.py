"""Portable references recorded in abbreviation research manifests."""

from __future__ import annotations

import os
from pathlib import Path


def relative_manifest_path(source: Path, manifest_dir: Path) -> str:
    """Describe a source relative to its manifest, falling back across drives."""
    try:
        return Path(os.path.relpath(source.resolve(), manifest_dir.resolve())).as_posix()
    except ValueError:
        return str(source.resolve())
