"""Abbreviation detectors."""

from .detect_bioc_abbreviations import detect_collection, detect_document

__all__ = ["detect_collection", "detect_document"]
