"""Prepare, serve, and export a small gold set for abbreviation sections."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
import mimetypes
import os
from pathlib import Path
import random
import re
import threading
import time
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import unquote, urlparse

import bioc

from ..bioc_io import load_collection
from ..ncbi import BIOC_PMCOA, NCBIClient, bioc_xml
from . import explore_bioc_abbr_tables as v1
from .paths import relative_manifest_path

LOG = logging.getLogger(__name__)
SCHEMA_VERSION = 1
DEFAULT_SAMPLE_SIZE = 112
DEFAULT_SEED = 17
V4_AUDIT_NEWLY_ACCEPTED = 80
V4_AUDIT_COMPACTED_PER_DISPOSITION = 10
V4_AUDIT_CONTROL_PER_SOURCE = 15
V4_AUDIT_HIGH_CONFIDENCE = 0.9
V5_VALIDATION_STRATA = {
    "deterministic_accepted": 80,
    "jev_or_pair_review": 40,
    "rejected": 40,
    "needs_parser_extension": 20,
    "unresolved_or_error": 20,
}
PMC_ID_CONVERTER = "https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/"
PRIORITY_TAGS = {
    "nonaccepted",
    "low_confidence",
    "unknown_orientation",
    "prose_warning",
    "unparsed",
    "recovery_candidate",
    "duplicate_source_record",
    "pattern_4",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    return list(_iter_jsonl(path))


def _iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"Invalid JSONL at {path}:{line_number}") from error
            if not isinstance(value, dict):
                raise ValueError(f"Expected an object at {path}:{line_number}")
            yield value


def _source_key(record: Mapping[str, Any]) -> tuple[str, str, int]:
    base = record["base"]
    return str(base["filename"]), str(base["document_id"]), int(base["start_index"])


def _resolution(record: Mapping[str, Any]) -> Mapping[str, Any] | None:
    response = record.get("jev_response")
    if not isinstance(response, Mapping):
        return None
    choices = response.get("choices")
    if not isinstance(choices, Mapping):
        return None
    value = choices.get("resolution")
    return value if isinstance(value, Mapping) else None


def _confidence(record: Mapping[str, Any]) -> float:
    resolution = _resolution(record)
    if resolution is not None:
        return float(resolution.get("confidence") or 0.0)
    return 1.0 if record.get("decision_source") == "DETERMINISTIC" else 0.0


def _choice_probability(choice: Mapping[str, Any] | None) -> float:
    if choice is None:
        return 0.0
    selected = str(choice.get("choice") or "")
    probabilities = choice.get("probabilities")
    if not isinstance(probabilities, Mapping):
        return 0.0
    return float(probabilities.get(selected) or 0.0)


def _orientation_choice(record: Mapping[str, Any]) -> str:
    response = record.get("jev_response")
    choices = response.get("choices") if isinstance(response, Mapping) else None
    if not isinstance(choices, Mapping):
        return ""
    candidate_index = int(record.get("selected_candidate_index") or 0)
    value = choices.get(f"orientation_{candidate_index:03d}")
    return str(value.get("choice") or "") if isinstance(value, Mapping) else ""


def _pattern(record: Mapping[str, Any]) -> str:
    candidate = record.get("final_candidate") or record.get("base", {}).get("best_candidate")
    if isinstance(candidate, Mapping):
        return str(candidate.get("pattern") or "NO_PATTERN")
    return "NO_PATTERN"


def _selection_tags(
    record: Mapping[str, Any], duplicate_keys: set[tuple[str, str, int]]
) -> list[str]:
    tags: set[str] = {_pattern(record).casefold()}
    disposition = str(record.get("disposition") or "")
    if disposition not in {"ACCEPTED", "ACCEPTED_WITH_REVIEW"}:
        tags.add("nonaccepted")
    if disposition == "ACCEPTED_WITH_REVIEW" or record.get("withheld_pairs"):
        tags.add("pair_review")
    if _confidence(record) <= 0.65 and record.get("jev_response"):
        tags.add("low_confidence")
    if record.get("base", {}).get("classification") == "UNPARSED":
        tags.add("unparsed")
    candidate = record.get("final_candidate")
    if isinstance(candidate, Mapping):
        if str(candidate.get("pattern") or "").startswith("RECOVERY_"):
            tags.add("recovery_candidate")
        if candidate.get("pattern") == "PATTERN_4":
            tags.add("pattern_4")
        if "PROSE_LIKE_PAIR_MEMBER" in (candidate.get("warnings") or []):
            tags.add("prose_warning")
        if any(pair.get("orientation") == "UNKNOWN" for pair in candidate.get("pairs") or []):
            tags.add("unknown_orientation")
        if candidate.get("unconsumed_abbr_passages"):
            tags.add("boundary_case")
    if _source_key(record) in duplicate_keys:
        tags.add("duplicate_source_record")
    return sorted(tags)


def select_records(
    records: Sequence[dict[str, Any]],
    *,
    sample_size: int = DEFAULT_SAMPLE_SIZE,
    seed: int = DEFAULT_SEED,
) -> list[tuple[dict[str, Any], list[str]]]:
    """Select all risky cases, then fill a deterministic pattern-stratified sample."""
    if sample_size < 1:
        raise ValueError("sample_size must be positive")
    counts: dict[tuple[str, str, int], int] = {}
    for record in records:
        key = _source_key(record)
        counts[key] = counts.get(key, 0) + 1
    duplicate_keys = {key for key, count in counts.items() if count > 1}

    deduplicated: dict[tuple[str, str, int], dict[str, Any]] = {}
    for record in records:
        deduplicated.setdefault(_source_key(record), record)
    tagged = [
        (record, _selection_tags(record, duplicate_keys))
        for record in deduplicated.values()
    ]
    selected = [item for item in tagged if PRIORITY_TAGS.intersection(item[1])]
    selected_keys = {_source_key(item[0]) for item in selected}

    rng = random.Random(seed)
    pools: dict[str, list[tuple[dict[str, Any], list[str]]]] = {}
    for item in tagged:
        if _source_key(item[0]) in selected_keys:
            continue
        pools.setdefault(_pattern(item[0]), []).append(item)
    for pool in pools.values():
        rng.shuffle(pool)

    patterns = sorted(pools)
    while len(selected) < sample_size and patterns:
        next_patterns = []
        for pattern in patterns:
            pool = pools[pattern]
            if pool and len(selected) < sample_size:
                selected.append(pool.pop())
            if pool:
                next_patterns.append(pattern)
        patterns = next_patterns
    return sorted(selected, key=lambda item: _source_key(item[0]))


def select_v5_validation_records(
    records: Sequence[dict[str, Any]],
    *,
    exclude_keys: set[tuple[str, str, int]] | None = None,
    strata: Mapping[str, int] = V5_VALIDATION_STRATA,
    seed: int = DEFAULT_SEED,
) -> list[tuple[dict[str, Any], list[str]]]:
    """Select a reproducible, pattern-stratified V5 holdout."""
    excluded = exclude_keys or set()
    deduplicated: dict[tuple[str, str, int], dict[str, Any]] = {}
    for record in records:
        key = _source_key(record)
        if key not in excluded:
            deduplicated.setdefault(key, record)

    pools: dict[str, list[dict[str, Any]]] = {name: [] for name in strata}
    for record in deduplicated.values():
        disposition = str(record.get("disposition") or "")
        source = str(record.get("decision_source") or "")
        if disposition == "ACCEPTED" and source == "DETERMINISTIC":
            stratum = "deterministic_accepted"
        elif disposition in {"ACCEPTED", "ACCEPTED_WITH_REVIEW"} and (
            source == "JEV"
            or disposition == "ACCEPTED_WITH_REVIEW"
            or bool(record.get("pair_reviews"))
        ):
            stratum = "jev_or_pair_review"
        elif disposition == "REJECTED":
            stratum = "rejected"
        elif disposition == "NEEDS_PARSER_EXTENSION":
            stratum = "needs_parser_extension"
        elif disposition in {"UNRESOLVED", "ERROR"}:
            stratum = "unresolved_or_error"
        else:
            continue
        pools[stratum].append(record)

    rng = random.Random(seed)
    selected: list[tuple[dict[str, Any], list[str]]] = []
    for stratum, requested in strata.items():
        if requested < 0:
            raise ValueError("V5 validation stratum sizes cannot be negative")
        by_pattern: dict[str, list[dict[str, Any]]] = {}
        for record in pools.get(stratum, []):
            by_pattern.setdefault(_pattern(record), []).append(record)
        for values in by_pattern.values():
            rng.shuffle(values)
        chosen: list[dict[str, Any]] = []
        patterns = sorted(by_pattern)
        while len(chosen) < requested and patterns:
            remaining = []
            for pattern in patterns:
                values = by_pattern[pattern]
                if values and len(chosen) < requested:
                    chosen.append(values.pop())
                if values:
                    remaining.append(pattern)
            patterns = remaining
        if len(chosen) != requested:
            raise ValueError(
                f"V5 validation stratum {stratum!r} requested {requested} "
                f"sections but only {len(chosen)} were available"
            )
        selected.extend(
            (record, ["v5_validation", f"v5_validation_{stratum}"])
            for record in chosen
        )
    return sorted(selected, key=lambda item: _source_key(item[0]))


def _stratified_audit_keys(
    metadata: Sequence[dict[str, Any]], count: int, seed: int
) -> list[tuple[str, str, int]]:
    pools: dict[str, list[dict[str, Any]]] = {}
    for value in metadata:
        pools.setdefault(str(value["pattern"]), []).append(value)
    rng = random.Random(seed)
    for pool in pools.values():
        rng.shuffle(pool)
    selected: list[tuple[str, str, int]] = []
    patterns = sorted(pools)
    while len(selected) < count and patterns:
        remaining_patterns = []
        for pattern in patterns:
            pool = pools[pattern]
            if pool and len(selected) < count:
                selected.append(pool.pop()["key"])
            if pool:
                remaining_patterns.append(pattern)
        patterns = remaining_patterns
    if len(selected) != count:
        raise ValueError(f"Requested {count} audit controls but only found {len(selected)}")
    return selected


def select_v4_audit_keys(
    comparison_records: Iterable[Mapping[str, Any]],
    records: Iterable[Mapping[str, Any]],
    *,
    newly_accepted_count: int = V4_AUDIT_NEWLY_ACCEPTED,
    compacted_per_disposition: int = V4_AUDIT_COMPACTED_PER_DISPOSITION,
    control_per_source: int = V4_AUDIT_CONTROL_PER_SOURCE,
    seed: int = DEFAULT_SEED,
) -> list[tuple[tuple[str, str, int], list[str]]]:
    """Select the targeted v4 audit strata without retaining full report rows."""
    if min(newly_accepted_count, compacted_per_disposition, control_per_source) < 0:
        raise ValueError("v4 audit stratum sizes cannot be negative")
    formerly_low_confidence_candidates = set()
    for record in comparison_records:
        resolution = _resolution(record)
        if (
            record.get("decision_source") == "JEV_LOW_CONFIDENCE"
            and resolution is not None
            and str(resolution.get("choice") or "").startswith("candidate_")
        ):
            formerly_low_confidence_candidates.add(_source_key(record))

    newly_accepted: list[dict[str, Any]] = []
    compacted: dict[str, list[dict[str, Any]]] = {
        "REJECTED": [],
        "NEEDS_PARSER_EXTENSION": [],
        "UNRESOLVED": [],
    }
    controls: dict[str, list[dict[str, Any]]] = {"DETERMINISTIC": [], "JEV": []}
    seen: set[tuple[str, str, int]] = set()
    for record in records:
        key = _source_key(record)
        if key in seen:
            continue
        seen.add(key)
        disposition = str(record.get("disposition") or "")
        candidate = record.get("final_candidate")
        candidate = candidate if isinstance(candidate, Mapping) else {}
        metadata = {
            "key": key,
            "pattern": _pattern(record),
            "pair_count": len(candidate.get("pairs") or []),
            "warnings": set(candidate.get("warnings") or []),
            "choice_probability": _choice_probability(_resolution(record)),
            "orientation_choice": _orientation_choice(record),
        }
        is_newly_accepted = (
            key in formerly_low_confidence_candidates and disposition == "ACCEPTED"
        )
        if is_newly_accepted:
            newly_accepted.append(metadata)
        if record.get("jev_request_compacted") is True and disposition in compacted:
            compacted[disposition].append(metadata)
        source = str(record.get("decision_source") or "")
        if (
            disposition == "ACCEPTED"
            and not is_newly_accepted
            and source in controls
            and (source == "DETERMINISTIC" or _confidence(record) >= V4_AUDIT_HIGH_CONFIDENCE)
        ):
            controls[source].append(metadata)

    def new_tags(value: Mapping[str, Any]) -> list[str]:
        tags = {"v4_newly_accepted"}
        warnings = value["warnings"]
        if value["orientation_choice"] == "mixed_or_unknown":
            tags.add("v4_orientation_edge")
        if "PROSE_LIKE_PAIR_MEMBER" in warnings:
            tags.add("v4_prose_warning")
        if str(value["pattern"]).startswith("RECOVERY_"):
            tags.add("v4_recovery")
        if "JEV_REVIEW_REQUIRED" in warnings:
            tags.add("v4_jev_review")
        return sorted(tags)

    tagged_new = [(value, new_tags(value)) for value in newly_accepted]
    mandatory = [
        item
        for item in tagged_new
        if set(item[1]) - {"v4_newly_accepted"}
    ]
    risk_key = lambda item: (
        item[0]["choice_probability"],
        -item[0]["pair_count"],
        item[0]["key"],
    )
    mandatory.sort(key=risk_key)
    if len(mandatory) > newly_accepted_count:
        raise ValueError(
            f"The {len(mandatory)} mandatory v4 audit cases exceed the "
            f"requested newly-accepted stratum of {newly_accepted_count}"
        )
    mandatory_keys = {item[0]["key"] for item in mandatory}
    fill = [item for item in tagged_new if item[0]["key"] not in mandatory_keys]
    fill.sort(key=risk_key)
    chosen_new = [*mandatory, *fill[: newly_accepted_count - len(mandatory)]]
    if len(chosen_new) != newly_accepted_count:
        raise ValueError(
            f"Requested {newly_accepted_count} newly accepted cases but only found "
            f"{len(chosen_new)}"
        )

    result = [(value["key"], tags) for value, tags in chosen_new]
    selected_keys = {key for key, _ in result}
    rng = random.Random(seed)
    for disposition in ("REJECTED", "NEEDS_PARSER_EXTENSION", "UNRESOLVED"):
        pool = compacted[disposition]
        rng.shuffle(pool)
        chosen = pool[:compacted_per_disposition]
        if len(chosen) != compacted_per_disposition:
            raise ValueError(
                f"Requested {compacted_per_disposition} compacted {disposition} cases "
                f"but only found {len(chosen)}"
            )
        disposition_tag = disposition.casefold()
        for value in chosen:
            if value["key"] in selected_keys:
                raise ValueError(f"Overlapping v4 audit stratum for {value['key']}")
            selected_keys.add(value["key"])
            result.append(
                (value["key"], ["v4_compacted", f"v4_compacted_{disposition_tag}"])
            )

    for offset, source in enumerate(("DETERMINISTIC", "JEV"), 1):
        available = [value for value in controls[source] if value["key"] not in selected_keys]
        keys = _stratified_audit_keys(available, control_per_source, seed + offset)
        tag = f"v4_control_{source.casefold()}"
        for key in keys:
            selected_keys.add(key)
            result.append((key, [tag]))
    return result


def _context_passage(index: int, passage: Any) -> dict[str, Any]:
    infons = dict(passage.infons or {})
    return {
        "index": index,
        "offset": getattr(passage, "offset", None),
        "section_type": str(infons.get("section_type") or ""),
        "type": str(infons.get("type") or ""),
        "text": str(passage.text or ""),
    }


def _load_contexts(
    bioc_input: Path | None, wanted: set[tuple[str, str]]
) -> dict[tuple[str, str], list[dict[str, Any]]]:
    if bioc_input is None or not bioc_input.exists():
        return {}
    sources = v1._input_files(bioc_input)
    wanted_files = {filename for filename, _ in wanted}
    result: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for source in sources:
        if source.name not in wanted_files:
            continue
        collection = load_collection(source)
        for document in collection.documents:
            key = source.name, str(document.id)
            if key in wanted:
                result[key] = [
                    _context_passage(index, passage)
                    for index, passage in enumerate(document.passages or [])
                ]
    return result


def _load_prepared_contexts(path: Path) -> dict[tuple[str, str], list[dict[str, Any]]]:
    if not path.exists():
        return {}
    result = {}
    for item in json.loads(path.read_text(encoding="utf-8")):
        context = item.get("document_context") or {}
        source = item.get("source") or {}
        if context.get("complete"):
            result[(str(source.get("filename")), str(source.get("document_id")))] = context.get("passages") or []
    return result


def _pmid_to_pmc(client: NCBIClient, pmids: Sequence[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for batch in client.batches(list(pmids), 200):
        response = json.loads(
            client.request(
                PMC_ID_CONVERTER,
                {"ids": ",".join(batch), "idtype": "pmid", "format": "json"},
            )
        )
        for record in response.get("records") or []:
            pmid = record.get("pmid")
            pmcid = record.get("pmcid")
            if pmid is not None and pmcid:
                result[str(pmid)] = str(pmcid)
    return result


def _fetch_full_contexts(pmids: Sequence[str]) -> dict[str, list[dict[str, Any]]]:
    """Fetch OA full-text BioC context for PMIDs whose local collection is absent."""
    if not pmids:
        return {}
    client = NCBIClient(
        email=os.environ.get("NCBI_EMAIL"),
        api_key=os.environ.get("NCBI_API_KEY"),
        delay=0.5,
    )
    mapping = _pmid_to_pmc(client, pmids)
    reverse = {pmc: pmid for pmid, pmc in mapping.items()}
    result: dict[str, list[dict[str, Any]]] = {}
    failed_batches: list[list[str]] = []

    def add_collection(collection: bioc.BioCCollection) -> None:
        for document in collection.documents:
            header = (document.passages[0].infons or {}) if document.passages else {}
            pmid = str(header.get("article-id_pmid") or "")
            if not pmid:
                document_id = str(document.id)
                normalized_pmc = (
                    document_id if document_id.startswith("PMC") else f"PMC{document_id}"
                )
                pmid = reverse.get(normalized_pmc, "")
            if pmid in mapping:
                result[pmid] = [
                    _context_passage(index, passage)
                    for index, passage in enumerate(document.passages or [])
                ]

    for batch in client.batches(sorted(reverse), 50):
        try:
            collection = bioc.loads(
                bioc_xml(client, BIOC_PMCOA, batch).decode("utf-8")
            )
        except Exception:
            LOG.exception("Unable to fetch BioC full-text batch containing %d PMC IDs", len(batch))
            failed_batches.append(batch)
            continue
        add_collection(collection)
    if failed_batches:
        time.sleep(5)
        for pmc in (pmc for batch in failed_batches for pmc in batch):
            try:
                add_collection(
                    bioc.loads(bioc_xml(client, BIOC_PMCOA, [pmc]).decode("utf-8"))
                )
            except Exception as error:
                LOG.warning("Unable to fetch BioC full text for %s: %s", pmc, error)
    LOG.info(
        "Fetched full BioC context for %d/%d selected PMIDs (%d mapped to PMC)",
        len(result),
        len(pmids),
        len(mapping),
    )
    return result


def _dictionary_orientation(
    pair: Mapping[str, Any], dictionary: Mapping[str, Mapping[str, int]] | None
) -> tuple[str, list[str]]:
    original = str(pair.get("orientation") or "UNKNOWN")
    evidence = [str(value) for value in pair.get("orientation_evidence") or []]
    if original != "UNKNOWN" or dictionary is None:
        return original, evidence
    first, second = str(pair.get("first") or ""), str(pair.get("second") or "")
    forward = int(dictionary.get(first, {}).get(second, 0))
    reverse = int(dictionary.get(second, {}).get(first, 0))
    if forward > reverse:
        return "FIRST_IS_SF", [*evidence, f"GOLD_DICTIONARY_FORWARD_{forward}"]
    if reverse > forward:
        return "SECOND_IS_SF", [*evidence, f"GOLD_DICTIONARY_REVERSE_{reverse}"]
    return original, evidence


def _pair_annotation(
    pair: Mapping[str, Any], dictionary: Mapping[str, Mapping[str, int]] | None
) -> dict[str, Any]:
    orientation, evidence = _dictionary_orientation(pair, dictionary)
    first, second = str(pair.get("first") or ""), str(pair.get("second") or "")
    if orientation == "FIRST_IS_SF":
        short_form, long_form = first, second
    elif orientation == "SECOND_IS_SF":
        short_form, long_form = second, first
    else:
        short_form = str(pair.get("short_form") or "")
        long_form = str(pair.get("long_form") or "")
    return {
        "short_form": short_form,
        "long_form": long_form,
        "orientation": orientation,
        "source_passage_indexes": [int(value) for value in pair.get("source_passage_indexes") or []],
        "source_first": first,
        "source_second": second,
        "orientation_evidence": evidence,
    }


def _context_matches_source(
    context: Sequence[Mapping[str, Any]], source_passages: Sequence[Mapping[str, Any]]
) -> bool:
    by_index = {int(passage["index"]): passage for passage in context}
    for source in source_passages:
        passage = by_index.get(int(source["index"]))
        if passage is None:
            return False
        source_text = " ".join(str(source.get("text") or "").split())
        context_text = " ".join(str(passage.get("text") or "").split())
        if source_text != context_text:
            return False
    return True


def _section_decision(disposition: str) -> str | None:
    return {
        "ACCEPTED": "valid_abbreviation_section",
        "ACCEPTED_WITH_REVIEW": "valid_abbreviation_section",
        "REJECTED": "not_abbreviation_information",
        "NEEDS_PARSER_EXTENSION": "needs_parser_extension",
    }.get(disposition)


def _item_id(key: tuple[str, str, int]) -> str:
    filename, document_id, start_index = key
    safe_file = re.sub(r"[^A-Za-z0-9]+", "-", Path(filename).stem).strip("-")
    return f"{safe_file}--{document_id}--p{start_index}"


def _build_item(
    record: Mapping[str, Any],
    tags: Sequence[str],
    contexts: Mapping[tuple[str, str], list[dict[str, Any]]],
    dictionary: Mapping[str, Mapping[str, int]] | None,
    *,
    prefill_fallback: bool = False,
    activate_fallback_pairs: bool = True,
) -> dict[str, Any]:
    key = _source_key(record)
    base = record["base"]
    source_passages = copy.deepcopy(base.get("source_passages") or [])
    context = contexts.get((key[0], key[1]))
    context_complete = context is not None and _context_matches_source(
        context, source_passages
    )
    if context is not None and not context_complete:
        LOG.warning(
            "Fetched/local full context did not align with source passages: %s document=%s start=%d",
            key[0],
            key[1],
            key[2],
        )
    passages = context if context is not None else source_passages
    if not context_complete:
        passages = source_passages
    candidate = record.get("final_candidate")
    fallback_candidate: Mapping[str, Any] | None = None
    fallback_candidate_index: int | None = None
    if not isinstance(candidate, Mapping) and prefill_fallback:
        candidates = record.get("candidates") or []
        if candidates and isinstance(candidates[0], Mapping):
            fallback_candidate_index = 0
            fallback_candidate = candidates[0]
            if activate_fallback_pairs:
                candidate = fallback_candidate
    pairs = [
        _pair_annotation(pair, dictionary)
        for pair in (candidate.get("pairs") if isinstance(candidate, Mapping) else []) or []
    ]
    positive_indexes = {
        index for pair in pairs for index in pair["source_passage_indexes"]
    }
    source_indexes = {int(value["index"]) for value in source_passages}
    passage_labels = {
        str(index): index in positive_indexes for index in sorted(source_indexes)
    }
    decision = _section_decision(str(record.get("disposition") or ""))
    annotation = {
        "section_decision": decision,
        "passage_labels": passage_labels,
        "end_index": candidate.get("end_index") if isinstance(candidate, Mapping) else None,
        "orientation": (
            pairs[0]["orientation"]
            if pairs and len({pair["orientation"] for pair in pairs}) == 1
            else "MIXED_OR_UNKNOWN"
        ),
        "pairs": pairs,
        "notes": "",
        "done": False,
        "annotator": "",
        "updated_at": None,
    }
    if fallback_candidate_index is not None:
        annotation["fallback_preannotation"] = {
            "candidate_index": fallback_candidate_index,
            "pattern": fallback_candidate.get("pattern"),
            "subpattern": fallback_candidate.get("subpattern"),
            "source_disposition": record.get("disposition"),
            "warnings": list(fallback_candidate.get("warnings") or []),
            "raw_pair_count": len(fallback_candidate.get("pairs") or []),
            "pairs_activated": activate_fallback_pairs,
        }
    response = record.get("jev_response")
    choices = response.get("choices") if isinstance(response, Mapping) else None
    pair_response = record.get("pair_jev_response")
    pair_choices = (
        pair_response.get("choices") if isinstance(pair_response, Mapping) else None
    )
    return {
        "id": _item_id(key),
        "source": {
            "filename": key[0],
            "document_id": key[1],
            "start_index": key[2],
            "identifiers": base.get("identifiers") or {},
            "section_title": str(base.get("title_text") or ""),
        },
        "selection_tags": list(tags),
        "document_context": {
            "complete": context_complete,
            "passages": passages,
            "annotated_passage_indexes": sorted(source_indexes),
        },
        "preannotation": {
            "method": "deterministic parser + cached Jev + frequency dictionary",
            "confidence": _confidence(record),
            "disposition": record.get("disposition"),
            "decision_source": record.get("decision_source"),
            "parser_pattern": _pattern(record),
            "selected_candidate_index": record.get("selected_candidate_index"),
            "jev_choices": copy.deepcopy(choices) if isinstance(choices, Mapping) else None,
            "pair_jev_choices": (
                copy.deepcopy(pair_choices)
                if isinstance(pair_choices, Mapping)
                else None
            ),
            "withheld_pairs": [
                _pair_annotation(pair, dictionary)
                for pair in record.get("withheld_pairs") or []
            ],
            "pair_reviews": copy.deepcopy(record.get("pair_reviews") or []),
            "jev_request_compacted": bool(record.get("jev_request_compacted")),
            "jev_attempts": int(record.get("jev_attempts") or 0),
            "annotation": copy.deepcopy(annotation),
        },
        "annotation": annotation,
    }


def prepare_gold_set(
    report_dir: Path | str,
    output_dir: Path | str,
    *,
    bioc_input: Path | str | None = None,
    dictionary_path: Path | str | None = None,
    sample_size: int = DEFAULT_SAMPLE_SIZE,
    seed: int = DEFAULT_SEED,
    fetch_missing_context: bool = False,
) -> dict[str, Any]:
    report_path = Path(report_dir)
    target = Path(output_dir)
    records = _read_jsonl(report_path / "sequences.jsonl")
    selected = select_records(records, sample_size=sample_size, seed=seed)
    wanted = {(item[0]["base"]["filename"], str(item[0]["base"]["document_id"])) for item in selected}
    contexts = _load_contexts(Path(bioc_input) if bioc_input is not None else None, wanted)
    for key, passages in _load_prepared_contexts(target / "items.json").items():
        contexts.setdefault(key, passages)
    if fetch_missing_context:
        missing_pmids = sorted(
            document_id
            for filename, document_id in wanted
            if (filename, document_id) not in contexts
        )
        fetched = _fetch_full_contexts(missing_pmids)
        for filename, document_id in wanted:
            if (filename, document_id) not in contexts and document_id in fetched:
                contexts[(filename, document_id)] = fetched[document_id]
    dictionary = (
        v1.load_ab3p_dictionary(dictionary_path) if dictionary_path is not None else None
    )
    items = [
        _build_item(record, tags, contexts, dictionary) for record, tags in selected
    ]
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "dataset_id": "abbr-gold-v1",
        "created_at": _utc_now(),
        "source_report": relative_manifest_path(report_path, target),
        "selection_seed": seed,
        "requested_sample_size": sample_size,
        "item_count": len(items),
        "full_context_items": sum(item["document_context"]["complete"] for item in items),
        "fallback_context_items": sum(not item["document_context"]["complete"] for item in items),
        "selection_tag_counts": {
            tag: sum(tag in item["selection_tags"] for item in items)
            for tag in sorted({tag for item in items for tag in item["selection_tags"]})
        },
    }
    target.mkdir(parents=True, exist_ok=True)
    (target / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    (target / "items.json").write_text(
        json.dumps(items, ensure_ascii=False), encoding="utf-8"
    )
    annotations_path = target / "annotations.json"
    if not annotations_path.exists():
        annotations_path.write_text(
            json.dumps(
                {
                    "schema_version": SCHEMA_VERSION,
                    "dataset_id": manifest["dataset_id"],
                    "updated_at": manifest["created_at"],
                    "annotations": {item["id"]: item["annotation"] for item in items},
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
    return manifest


def prepare_v4_audit_set(
    report_dir: Path | str,
    comparison_report_dir: Path | str,
    output_dir: Path | str,
    *,
    bioc_input: Path | str | None = None,
    dictionary_path: Path | str | None = None,
    newly_accepted_count: int = V4_AUDIT_NEWLY_ACCEPTED,
    compacted_per_disposition: int = V4_AUDIT_COMPACTED_PER_DISPOSITION,
    control_per_source: int = V4_AUDIT_CONTROL_PER_SOURCE,
    seed: int = DEFAULT_SEED,
) -> dict[str, Any]:
    """Prepare the targeted v4 verification set with editable preannotations."""
    report_path = Path(report_dir)
    comparison_path = Path(comparison_report_dir)
    target = Path(output_dir)
    selected = select_v4_audit_keys(
        _iter_jsonl(comparison_path / "sequences.jsonl"),
        _iter_jsonl(report_path / "sequences.jsonl"),
        newly_accepted_count=newly_accepted_count,
        compacted_per_disposition=compacted_per_disposition,
        control_per_source=control_per_source,
        seed=seed,
    )
    tags_by_key = dict(selected)
    records_by_key = {
        _source_key(record): record
        for record in _iter_jsonl(report_path / "sequences.jsonl")
        if _source_key(record) in tags_by_key
    }
    missing = [key for key, _ in selected if key not in records_by_key]
    if missing:
        raise ValueError(f"Selected v4 audit records are missing from the report: {missing}")

    wanted = {(key[0], key[1]) for key, _ in selected}
    contexts = _load_contexts(
        Path(bioc_input) if bioc_input is not None else None, wanted
    )
    for key, passages in _load_prepared_contexts(target / "items.json").items():
        contexts.setdefault(key, passages)
    dictionary = (
        v1.load_ab3p_dictionary(dictionary_path) if dictionary_path is not None else None
    )
    items = []
    for key, audit_tags in selected:
        record = records_by_key[key]
        tags = sorted(set(audit_tags) | set(_selection_tags(record, set())))
        items.append(
            _build_item(
                record,
                tags,
                contexts,
                dictionary,
                prefill_fallback=True,
                activate_fallback_pairs=False,
            )
        )

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "dataset_id": "abbr-v4-audit-v1",
        "created_at": _utc_now(),
        "source_report": relative_manifest_path(report_path, target),
        "comparison_report": relative_manifest_path(comparison_path, target),
        "selection_seed": seed,
        "selection_policy": {
            "newly_accepted_from_v3_low_confidence": newly_accepted_count,
            "compacted_per_disposition": compacted_per_disposition,
            "deterministic_controls": control_per_source,
            "high_confidence_jev_controls": control_per_source,
            "high_confidence_floor": V4_AUDIT_HIGH_CONFIDENCE,
        },
        "preannotation_policy": (
            "v4 final candidate when accepted; parser candidate 0 provenance only, "
            "with no active pairs, when v4 has no final candidate"
        ),
        "item_count": len(items),
        "preannotated_pair_count": sum(
            len(item["annotation"]["pairs"]) for item in items
        ),
        "pair_level_preannotation_items": sum(
            bool(item["annotation"]["pairs"]) for item in items
        ),
        "decision_only_items": sum(
            not item["annotation"]["pairs"] for item in items
        ),
        "fallback_preannotation_items": sum(
            "fallback_preannotation" in item["annotation"] for item in items
        ),
        "full_context_items": sum(item["document_context"]["complete"] for item in items),
        "fallback_context_items": sum(
            not item["document_context"]["complete"] for item in items
        ),
        "selection_tag_counts": {
            tag: sum(tag in item["selection_tags"] for item in items)
            for tag in sorted({tag for item in items for tag in item["selection_tags"]})
        },
    }
    target.mkdir(parents=True, exist_ok=True)
    (target / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    (target / "items.json").write_text(
        json.dumps(items, ensure_ascii=False), encoding="utf-8"
    )
    annotations_path = target / "annotations.json"
    if not annotations_path.exists():
        annotations_path.write_text(
            json.dumps(
                {
                    "schema_version": SCHEMA_VERSION,
                    "dataset_id": manifest["dataset_id"],
                    "updated_at": manifest["created_at"],
                    "annotations": {item["id"]: item["annotation"] for item in items},
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
    return manifest


def prepare_v5_validation_set(
    report_dir: Path | str,
    output_dir: Path | str,
    *,
    bioc_input: Path | str | None = None,
    dictionary_path: Path | str | None = None,
    exclude_snapshot: Path | str | None = None,
    seed: int = DEFAULT_SEED,
    strata: Mapping[str, int] = V5_VALIDATION_STRATA,
) -> dict[str, Any]:
    """Prepare an unseen, preannotated V5 release-validation holdout."""
    report_path = Path(report_dir)
    target = Path(output_dir)
    excluded: set[tuple[str, str, int]] = set()
    if exclude_snapshot is not None:
        snapshot = Path(exclude_snapshot)
        manifest = json.loads((snapshot / "manifest.json").read_text(encoding="utf-8"))
        excluded = {
            (
                str(record["source"]["filename"]),
                str(record["source"]["document_id"]),
                int(record["source"]["start_index"]),
            )
            for record in _iter_jsonl(snapshot / manifest["records_file"])
        }
    selected = select_v5_validation_records(
        _read_jsonl(report_path / "sequences.jsonl"),
        exclude_keys=excluded,
        strata=strata,
        seed=seed,
    )
    wanted = {
        (record["base"]["filename"], str(record["base"]["document_id"]))
        for record, _ in selected
    }
    contexts = _load_contexts(
        Path(bioc_input) if bioc_input is not None else None, wanted
    )
    for key, passages in _load_prepared_contexts(target / "items.json").items():
        contexts.setdefault(key, passages)
    dictionary = (
        v1.load_ab3p_dictionary(dictionary_path) if dictionary_path is not None else None
    )
    items = [
        _build_item(
            record,
            sorted(set(tags) | set(_selection_tags(record, set()))),
            contexts,
            dictionary,
            prefill_fallback=True,
            activate_fallback_pairs=False,
        )
        for record, tags in selected
    ]
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "dataset_id": "abbr-v5-validation-v1",
        "created_at": _utc_now(),
        "source_report": relative_manifest_path(report_path, target),
        "excluded_snapshot": (
            relative_manifest_path(Path(exclude_snapshot), target)
            if exclude_snapshot is not None
            else None
        ),
        "selection_seed": seed,
        "selection_policy": dict(strata),
        "preannotation_policy": (
            "V5 emitted pairs are active preannotations; withheld and nonaccepted "
            "candidate pairs remain provenance-only"
        ),
        "item_count": len(items),
        "preannotated_pair_count": sum(
            len(item["annotation"]["pairs"]) for item in items
        ),
        "full_context_items": sum(item["document_context"]["complete"] for item in items),
        "fallback_context_items": sum(
            not item["document_context"]["complete"] for item in items
        ),
        "selection_tag_counts": {
            tag: sum(tag in item["selection_tags"] for item in items)
            for tag in sorted({tag for item in items for tag in item["selection_tags"]})
        },
    }
    target.mkdir(parents=True, exist_ok=True)
    (target / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    (target / "items.json").write_text(
        json.dumps(items, ensure_ascii=False), encoding="utf-8"
    )
    annotations_path = target / "annotations.json"
    if not annotations_path.exists():
        annotations_path.write_text(
            json.dumps(
                {
                    "schema_version": SCHEMA_VERSION,
                    "dataset_id": manifest["dataset_id"],
                    "updated_at": manifest["created_at"],
                    "annotations": {
                        item["id"]: item["annotation"] for item in items
                    },
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
    return manifest


class AnnotationStore:
    def __init__(self, data_dir: Path, annotations_path: Path | None = None) -> None:
        self.data_dir = data_dir
        self.lock = threading.Lock()
        self.manifest = json.loads((data_dir / "manifest.json").read_text(encoding="utf-8"))
        self.items = json.loads((data_dir / "items.json").read_text(encoding="utf-8"))
        self.items_by_id = {item["id"]: item for item in self.items}
        self.item_ids = {item["id"] for item in self.items}
        self.annotations_path = annotations_path or data_dir / "annotations.json"

    def _annotations(self) -> dict[str, Any]:
        return json.loads(self.annotations_path.read_text(encoding="utf-8"))

    def dataset(self) -> dict[str, Any]:
        state = self._annotations()
        annotations = state.get("annotations") or {}
        items = []
        for item in self.items:
            annotation = annotations.get(item["id"], item["annotation"])
            preannotation = {
                key: value
                for key, value in item["preannotation"].items()
                if key != "annotation"
            }
            items.append(
                {
                    "id": item["id"],
                    "source": item["source"],
                    "selection_tags": item["selection_tags"],
                    "preannotation": preannotation,
                    "annotation": {
                        "done": bool(annotation.get("done")),
                        "section_decision": annotation.get("section_decision"),
                        "updated_at": annotation.get("updated_at"),
                        "fallback_preannotation": annotation.get(
                            "fallback_preannotation"
                        ),
                    },
                }
            )
        return {
            "manifest": self.manifest,
            "annotations_source": self.annotations_path.name,
            "items": items,
        }

    def item(self, item_id: str) -> dict[str, Any]:
        item = self.items_by_id[item_id]
        annotations = self._annotations().get("annotations") or {}
        merged = copy.deepcopy(item)
        merged["annotation"] = annotations.get(item_id, item["annotation"])
        merged.get("preannotation", {}).pop("annotation", None)
        return merged

    def save(self, item_id: str, annotation: Mapping[str, Any]) -> dict[str, Any]:
        if item_id not in self.item_ids:
            raise KeyError(item_id)
        value = copy.deepcopy(dict(annotation))
        value["updated_at"] = _utc_now()
        with self.lock:
            state = self._annotations()
            state.setdefault("annotations", {})[item_id] = value
            state["updated_at"] = value["updated_at"]
            temporary = self.annotations_path.with_suffix(".json.tmp")
            temporary.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
            temporary.replace(self.annotations_path)
        return value

    def export(self) -> Path:
        state = self._annotations()
        annotations = state.get("annotations") or {}
        path = self.data_dir / "gold_annotations.jsonl"
        temporary = path.with_suffix(".jsonl.tmp")
        with temporary.open("w", encoding="utf-8") as stream:
            for item in self.items:
                annotation = annotations.get(item["id"], item["annotation"])
                if not annotation.get("done"):
                    continue
                stream.write(
                    json.dumps(
                        {
                            "schema_version": SCHEMA_VERSION,
                            "id": item["id"],
                            "source": item["source"],
                            "selection_tags": item["selection_tags"],
                            "annotation": annotation,
                            "preannotation": item["preannotation"],
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
        temporary.replace(path)
        return path


def _pair_source_orientation(
    item: Mapping[str, Any],
    annotation: Mapping[str, Any],
    pair: Mapping[str, Any],
) -> str | None:
    """Infer whether the short or long form occurs first in the source."""
    short_form = " ".join(str(pair.get("short_form") or "").split()).casefold()
    long_form = " ".join(str(pair.get("long_form") or "").split()).casefold()
    if not short_form or not long_form or short_form == long_form:
        return None

    passages = {
        int(passage["index"]): passage
        for passage in item.get("document_context", {}).get("passages", [])
    }
    labels = annotation.get("passage_labels") or {}
    referenced = [int(value) for value in pair.get("source_passage_indexes") or []]
    positive = [int(value) for value, enabled in labels.items() if enabled]
    annotated = [
        int(value)
        for value in item.get("document_context", {}).get(
            "annotated_passage_indexes", []
        )
    ]
    indexes = list(dict.fromkeys([*referenced, *positive, *annotated]))
    groups = ([referenced] if referenced else []) + [[index] for index in indexes]
    for group in groups:
        text = " ".join(
            " ".join(str(passages[index].get("text") or "").split())
            for index in group
            if index in passages
        ).casefold()
        short_position = text.find(short_form)
        long_position = text.find(long_form)
        if short_position < 0 or long_position < 0 or short_position == long_position:
            continue
        return "FIRST_IS_SF" if short_position < long_position else "SECOND_IS_SF"
    return None


def repair_unknown_pair_orientations(
    data_dir: Path,
    output_path: Path | None = None,
    annotations_path: Path | None = None,
) -> dict[str, Any]:
    """Write a review copy with deterministically repairable orientations filled."""
    source_path = annotations_path or data_dir / "annotations.json"
    target_path = output_path or data_dir / "annotations.orientations_fixed.json"
    if source_path.resolve() == target_path.resolve():
        raise ValueError("orientation repair must write to a copy, not annotations.json")
    if target_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing repair copy: {target_path}")

    items = json.loads((data_dir / "items.json").read_text(encoding="utf-8"))
    items_by_id = {str(item["id"]): item for item in items}
    state = json.loads(source_path.read_text(encoding="utf-8"))
    annotations = state.get("annotations") or {}
    repaired_from_source = 0
    repaired_from_section = 0
    unresolved: list[dict[str, Any]] = []

    for item_id, annotation in annotations.items():
        if not annotation.get("done"):
            continue
        item = items_by_id.get(str(item_id))
        if item is None:
            continue
        section_orientation = annotation.get("orientation")
        for pair_index, pair in enumerate(annotation.get("pairs") or []):
            if pair.get("orientation") != "UNKNOWN":
                continue
            orientation = _pair_source_orientation(item, annotation, pair)
            if orientation is not None:
                repaired_from_source += 1
            elif section_orientation in {"FIRST_IS_SF", "SECOND_IS_SF"}:
                orientation = str(section_orientation)
                repaired_from_section += 1
            else:
                unresolved.append({"item_id": item_id, "pair_index": pair_index})
                continue
            pair["orientation"] = orientation

    target_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = target_path.with_suffix(target_path.suffix + ".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    temporary.replace(target_path)
    return {
        "source": str(source_path.resolve()),
        "output": str(target_path.resolve()),
        "repaired": repaired_from_source + repaired_from_section,
        "repaired_from_source": repaired_from_source,
        "repaired_from_section": repaired_from_section,
        "unresolved": unresolved,
    }


def prefill_fallback_candidates(
    data_dir: Path,
    report_dir: Path,
    output_path: Path | None = None,
) -> dict[str, Any]:
    """Write a review copy populated from the best available parser candidates."""
    source_path = data_dir / "annotations.json"
    target_path = output_path or data_dir / "annotations.fallback_prefilled.json"
    if source_path.resolve() == target_path.resolve():
        raise ValueError("fallback prefill must write to a copy, not annotations.json")
    if target_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing prefill copy: {target_path}")

    items = json.loads((data_dir / "items.json").read_text(encoding="utf-8"))
    state = json.loads(source_path.read_text(encoding="utf-8"))
    annotations = state.get("annotations") or {}
    reports = {
        _source_key(record): record
        for record in _read_jsonl(report_dir / "sequences.jsonl")
    }
    prefilled: list[dict[str, Any]] = []

    for item in items:
        item_id = str(item["id"])
        annotation = annotations.get(item_id)
        if not isinstance(annotation, dict):
            continue
        if (
            annotation.get("done")
            or annotation.get("pairs")
            or annotation.get("section_decision") == "not_abbreviation_information"
        ):
            continue
        source = item["source"]
        key = (
            str(source["filename"]),
            str(source["document_id"]),
            int(source["start_index"]),
        )
        report = reports.get(key)
        candidates = (report or {}).get("candidates") or []
        if not candidates:
            continue
        candidate_index = 0
        candidate = candidates[candidate_index]
        pairs = [_pair_annotation(pair, None) for pair in candidate.get("pairs") or []]
        if not pairs:
            continue

        labels = annotation.setdefault("passage_labels", {})
        for pair in pairs:
            for index in pair["source_passage_indexes"]:
                labels[str(index)] = True
        orientations = {pair["orientation"] for pair in pairs}
        annotation["pairs"] = pairs
        annotation["end_index"] = candidate.get("end_index")
        annotation["orientation"] = (
            next(iter(orientations))
            if len(orientations) == 1
            else "MIXED_OR_UNKNOWN"
        )
        annotation["fallback_preannotation"] = {
            "candidate_index": candidate_index,
            "pattern": candidate.get("pattern"),
            "subpattern": candidate.get("subpattern"),
            "source_disposition": report.get("disposition"),
            "warnings": list(candidate.get("warnings") or []),
        }
        prefilled.append(
            {
                "item_id": item_id,
                "candidate_index": candidate_index,
                "pattern": candidate.get("pattern"),
                "pairs": len(pairs),
                "end_index": candidate.get("end_index"),
            }
        )

    target_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = target_path.with_suffix(target_path.suffix + ".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    temporary.replace(target_path)
    return {
        "source": str(source_path.resolve()),
        "output": str(target_path.resolve()),
        "prefilled_sections": len(prefilled),
        "prefilled_pairs": sum(item["pairs"] for item in prefilled),
        "items": prefilled,
    }


def _handler(store: AnnotationStore, static_dir: Path):
    class Handler(SimpleHTTPRequestHandler):
        def _write_payload(self, payload: bytes) -> None:
            for offset in range(0, len(payload), 32 * 1024):
                self.wfile.write(payload[offset : offset + 32 * 1024])
                self.wfile.flush()
            self.close_connection = True

        def _json(self, value: Any, status: HTTPStatus = HTTPStatus.OK) -> None:
            payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Connection", "close")
            self.end_headers()
            self._write_payload(payload)

        def do_GET(self) -> None:  # noqa: N802
            path = urlparse(self.path).path
            if path == "/api/dataset":
                self._json(store.dataset())
                return
            item_prefix = "/api/items/"
            if path.startswith(item_prefix):
                try:
                    self._json(store.item(unquote(path[len(item_prefix) :])))
                except KeyError:
                    self.send_error(HTTPStatus.NOT_FOUND, "Unknown annotation item")
                return
            relative = unquote(path.lstrip("/")) or "index.html"
            candidate = (static_dir / relative).resolve()
            if static_dir.resolve() not in candidate.parents and candidate != static_dir.resolve():
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            if not candidate.is_file():
                candidate = static_dir / "index.html"
            if not candidate.is_file():
                self.send_error(HTTPStatus.NOT_FOUND, "Build the annotation UI first")
                return
            payload = candidate.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", mimetypes.guess_type(candidate.name)[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Connection", "close")
            self.end_headers()
            self._write_payload(payload)

        def do_PUT(self) -> None:  # noqa: N802
            prefix = "/api/annotations/"
            path = urlparse(self.path).path
            if not path.startswith(prefix):
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            try:
                length = int(self.headers.get("Content-Length") or "0")
                if length > 2_000_000:
                    raise ValueError("annotation payload is too large")
                value = json.loads(self.rfile.read(length))
                if not isinstance(value, Mapping):
                    raise ValueError("annotation must be a JSON object")
                saved = store.save(unquote(path[len(prefix) :]), value)
            except KeyError:
                self.send_error(HTTPStatus.NOT_FOUND, "Unknown annotation item")
                return
            except (ValueError, json.JSONDecodeError) as error:
                self._json({"error": str(error)}, HTTPStatus.BAD_REQUEST)
                return
            self._json(saved)

        def do_POST(self) -> None:  # noqa: N802
            if urlparse(self.path).path != "/api/export":
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            self._json({"path": str(store.export().resolve())})

        def log_message(self, format: str, *args: Any) -> None:
            LOG.info("annotation-server " + format, *args)

    return Handler


def serve(
    data_dir: Path,
    static_dir: Path,
    host: str,
    port: int,
    annotations_path: Path | None = None,
) -> None:
    store = AnnotationStore(data_dir, annotations_path)
    server = ThreadingHTTPServer((host, port), _handler(store, static_dir))
    LOG.info("Serving Abbreviation Gold Studio at http://%s:%d", host, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    prepare = subparsers.add_parser("prepare")
    prepare.add_argument("--report-dir", type=Path, default=Path("experiments/abbreviations/reports/sample-jev-baseline"))
    prepare.add_argument("--output-dir", type=Path, default=Path("annotations/abbreviations/gold"))
    prepare.add_argument("--bioc-input", type=Path)
    prepare.add_argument("--dictionary", type=Path)
    prepare.add_argument(
        "--fetch-missing-context",
        action="store_true",
        help="fetch OA full-text BioC documents from NCBI when local source files are absent",
    )
    prepare.add_argument("--sample-size", type=int, default=DEFAULT_SAMPLE_SIZE)
    prepare.add_argument("--seed", type=int, default=DEFAULT_SEED)
    audit = subparsers.add_parser(
        "prepare-v4-audit",
        help="prepare a targeted v4 verification set with editable preannotations",
    )
    audit.add_argument("--report-dir", type=Path, default=Path("work/abbr-full-cascade-v4"))
    audit.add_argument(
        "--comparison-report-dir",
        type=Path,
        default=Path("work/abbr-full-cascade-v3"),
    )
    audit.add_argument(
        "--output-dir",
        type=Path,
        default=Path("annotations/abbreviations/v4-audit"),
    )
    audit.add_argument("--bioc-input", type=Path)
    audit.add_argument("--dictionary", type=Path)
    audit.add_argument(
        "--newly-accepted-count", type=int, default=V4_AUDIT_NEWLY_ACCEPTED
    )
    audit.add_argument(
        "--compacted-per-disposition",
        type=int,
        default=V4_AUDIT_COMPACTED_PER_DISPOSITION,
    )
    audit.add_argument(
        "--control-per-source", type=int, default=V4_AUDIT_CONTROL_PER_SOURCE
    )
    audit.add_argument("--seed", type=int, default=DEFAULT_SEED)
    validation = subparsers.add_parser(
        "prepare-v5-validation",
        help="prepare a preannotated, unseen V5 release-validation holdout",
    )
    validation.add_argument("--report-dir", type=Path, required=True)
    validation.add_argument(
        "--output-dir",
        type=Path,
        default=Path("annotations/abbreviations/v5-validation"),
    )
    validation.add_argument("--bioc-input", type=Path)
    validation.add_argument("--dictionary", type=Path)
    validation.add_argument(
        "--exclude-snapshot",
        type=Path,
        default=Path(
            "annotations/abbreviations/v4-audit/snapshots/abbr-v4-audit-v1.0.0"
        ),
    )
    for stratum, default in V5_VALIDATION_STRATA.items():
        validation.add_argument(
            f"--{stratum.replace('_', '-')}-count",
            dest=f"{stratum}_count",
            type=int,
            default=default,
        )
    validation.add_argument("--seed", type=int, default=DEFAULT_SEED)
    server = subparsers.add_parser("serve")
    server.add_argument("--data-dir", type=Path, default=Path("annotations/abbreviations/gold"))
    server.add_argument(
        "--static-dir", type=Path, default=Path("tools/abbr_annotation/dist")
    )
    server.add_argument("--host", default="127.0.0.1")
    server.add_argument("--port", type=int, default=8765)
    server.add_argument(
        "--annotations",
        type=Path,
        help="annotation JSON to load and autosave instead of data-dir/annotations.json",
    )
    export = subparsers.add_parser("export")
    export.add_argument("--data-dir", type=Path, default=Path("annotations/abbreviations/gold"))
    repair = subparsers.add_parser(
        "repair-orientations",
        help="write a copy with deterministic UNKNOWN pair orientations repaired",
    )
    repair.add_argument("--data-dir", type=Path, default=Path("annotations/abbreviations/gold"))
    repair.add_argument(
        "--annotations",
        type=Path,
        help="annotation JSON to repair instead of data-dir/annotations.json",
    )
    repair.add_argument("--output", type=Path)
    prefill = subparsers.add_parser(
        "prefill-fallbacks",
        help="write a review copy populated from nonaccepted parser candidates",
    )
    prefill.add_argument("--data-dir", type=Path, default=Path("annotations/abbreviations/gold"))
    prefill.add_argument(
        "--report-dir", type=Path, default=Path("experiments/abbreviations/reports/sample-jev-baseline")
    )
    prefill.add_argument("--output", type=Path)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    if args.command == "prepare":
        manifest = prepare_gold_set(
            args.report_dir,
            args.output_dir,
            bioc_input=args.bioc_input,
            dictionary_path=args.dictionary,
            sample_size=args.sample_size,
            seed=args.seed,
            fetch_missing_context=args.fetch_missing_context,
        )
        print(json.dumps(manifest, indent=2))
    elif args.command == "prepare-v4-audit":
        manifest = prepare_v4_audit_set(
            args.report_dir,
            args.comparison_report_dir,
            args.output_dir,
            bioc_input=args.bioc_input,
            dictionary_path=args.dictionary,
            newly_accepted_count=args.newly_accepted_count,
            compacted_per_disposition=args.compacted_per_disposition,
            control_per_source=args.control_per_source,
            seed=args.seed,
        )
        print(json.dumps(manifest, indent=2))
    elif args.command == "prepare-v5-validation":
        manifest = prepare_v5_validation_set(
            args.report_dir,
            args.output_dir,
            bioc_input=args.bioc_input,
            dictionary_path=args.dictionary,
            exclude_snapshot=args.exclude_snapshot,
            seed=args.seed,
            strata={
                name: getattr(args, f"{name}_count")
                for name in V5_VALIDATION_STRATA
            },
        )
        print(json.dumps(manifest, indent=2))
    elif args.command == "serve":
        serve(
            args.data_dir,
            args.static_dir,
            args.host,
            args.port,
            annotations_path=args.annotations,
        )
    elif args.command == "export":
        print(AnnotationStore(args.data_dir).export())
    elif args.command == "repair-orientations":
        print(
            json.dumps(
                repair_unknown_pair_orientations(
                    args.data_dir, args.output, args.annotations
                ),
                indent=2,
            )
        )
    else:
        print(
            json.dumps(
                prefill_fallback_candidates(
                    args.data_dir, args.report_dir, args.output
                ),
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
