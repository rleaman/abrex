"""Create versioned abbreviation gold snapshots and evaluate parser reports."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Iterable, Mapping

from .abbr_gold import _pair_annotation, _read_jsonl
from .paths import relative_manifest_path

SNAPSHOT_SCHEMA_VERSION = 1
EVALUATION_SCHEMA_VERSION = 2
VALID_DECISIONS = {
    "valid_abbreviation_section",
    "not_abbreviation_information",
    "needs_parser_extension",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def _write_jsonl(path: Path, values: Iterable[Mapping[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as stream:
        for value in values:
            stream.write(json.dumps(value, ensure_ascii=False) + "\n")


def _source_key(value: Mapping[str, Any]) -> tuple[str, str, int]:
    source = value["source"]
    return (
        str(source["filename"]),
        str(source["document_id"]),
        int(source["start_index"]),
    )


def _report_key(value: Mapping[str, Any]) -> tuple[str, str, int]:
    base = value["base"]
    return (
        str(base["filename"]),
        str(base["document_id"]),
        int(base["start_index"]),
    )


def _validate_gold_annotation(item_id: str, annotation: Mapping[str, Any]) -> None:
    decision = annotation.get("section_decision")
    if decision not in VALID_DECISIONS:
        raise ValueError(f"Completed annotation {item_id} has invalid decision {decision!r}")
    pairs = annotation.get("pairs") or []
    labels = annotation.get("passage_labels") or {}
    if decision == "not_abbreviation_information":
        if pairs or any(labels.values()):
            raise ValueError(f"Negative annotation {item_id} contains positive content")
        return
    if decision == "needs_parser_extension" and not pairs:
        return
    if not pairs:
        raise ValueError(f"Positive annotation {item_id} has no abbreviation pairs")
    for pair_index, pair in enumerate(pairs):
        if not str(pair.get("short_form") or "").strip():
            raise ValueError(f"Annotation {item_id} pair {pair_index} has no short form")
        if not str(pair.get("long_form") or "").strip():
            raise ValueError(f"Annotation {item_id} pair {pair_index} has no long form")
        if pair.get("orientation") not in {"FIRST_IS_SF", "SECOND_IS_SF"}:
            raise ValueError(
                f"Annotation {item_id} pair {pair_index} has unresolved orientation"
            )
        indexes = [int(value) for value in pair.get("source_passage_indexes") or []]
        if not indexes or any(not labels.get(str(index), False) for index in indexes):
            raise ValueError(
                f"Annotation {item_id} pair {pair_index} lacks positive source passages"
            )


def create_snapshot(
    data_dir: Path,
    annotations_path: Path,
    output_root: Path,
    version: str,
) -> dict[str, Any]:
    """Export completed annotations to a self-contained, versioned snapshot."""
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", version):
        raise ValueError("version must contain only letters, digits, '.', '_', or '-'")
    target = output_root / version
    if target.exists():
        raise FileExistsError(f"Refusing to overwrite existing snapshot: {target}")

    dataset_manifest = json.loads(
        (data_dir / "manifest.json").read_text(encoding="utf-8")
    )
    items = json.loads((data_dir / "items.json").read_text(encoding="utf-8"))
    annotation_state = json.loads(annotations_path.read_text(encoding="utf-8"))
    annotations = annotation_state.get("annotations") or {}
    records: list[dict[str, Any]] = []
    for item in items:
        item_id = str(item["id"])
        annotation = annotations.get(item_id, item.get("annotation") or {})
        if not annotation.get("done"):
            continue
        _validate_gold_annotation(item_id, annotation)
        annotated_indexes = {
            int(value)
            for value in item.get("document_context", {}).get(
                "annotated_passage_indexes", []
            )
        }
        source_passages = [
            passage
            for passage in item.get("document_context", {}).get("passages", [])
            if int(passage["index"]) in annotated_indexes
        ]
        records.append(
            {
                "schema_version": SNAPSHOT_SCHEMA_VERSION,
                "id": item_id,
                "source": copy.deepcopy(item["source"]),
                "selection_tags": list(item.get("selection_tags") or []),
                "preannotation": {
                    key: copy.deepcopy(value)
                    for key, value in (item.get("preannotation") or {}).items()
                    if key != "annotation"
                },
                "context_complete": bool(
                    item.get("document_context", {}).get("complete")
                ),
                "source_passages": source_passages,
                "annotation": copy.deepcopy(annotation),
            }
        )
    if not records:
        raise ValueError("No completed annotations were available for the snapshot")

    target.mkdir(parents=True)
    records_path = target / "records.jsonl"
    _write_jsonl(records_path, records)
    decision_counts = Counter(
        record["annotation"]["section_decision"] for record in records
    )
    manifest = {
        "schema_version": SNAPSHOT_SCHEMA_VERSION,
        "snapshot_id": version,
        "dataset_id": dataset_manifest.get("dataset_id"),
        "created_at": _utc_now(),
        "annotation_grain": "source_occurrence",
        "duplicates_policy": "preserve repeated source occurrences",
        "normalization_policy": "human-normalized short and long forms",
        "source": {
            "annotations_path": relative_manifest_path(annotations_path, target),
            "annotations_sha256": _sha256(annotations_path),
            "annotations_updated_at": annotation_state.get("updated_at"),
            "items_sha256": _sha256(data_dir / "items.json"),
        },
        "completed_sections": len(records),
        "completed_pairs": sum(
            len(record["annotation"].get("pairs") or []) for record in records
        ),
        "decision_counts": dict(sorted(decision_counts.items())),
        "records_file": records_path.name,
        "records_sha256": _sha256(records_path),
    }
    _write_json(target / "manifest.json", manifest)
    return manifest


def _collapsed(value: Any) -> str:
    return " ".join(str(value or "").split())


def _exact_pair_key(pair: Mapping[str, Any]) -> tuple[str, str]:
    return _collapsed(pair.get("short_form")), _collapsed(pair.get("long_form"))


def _normalized_pair_key(pair: Mapping[str, Any]) -> tuple[str, str]:
    short_form, long_form = _exact_pair_key(pair)
    short_form = re.sub(
        r"^\s*abbreviations?\s+used\s+in\s+(?:this\s+)?(?:review|article|study)\s*:\s*",
        "",
        short_form,
        flags=re.IGNORECASE,
    ).casefold().rstrip(" .:;")
    long_form = long_form.casefold().rstrip(".")
    if len(short_form) > 2 and short_form.startswith("(") and short_form.endswith(")"):
        short_form = short_form[1:-1].strip()
    return short_form, long_form


def _counter_pairs(
    pairs: Iterable[Mapping[str, Any]], *, normalized: bool
) -> Counter[tuple[str, str]]:
    key = _normalized_pair_key if normalized else _exact_pair_key
    return Counter(key(pair) for pair in pairs)


def _prediction_pairs(candidate: Mapping[str, Any] | None) -> list[dict[str, Any]]:
    if candidate is None:
        return []
    result = []
    for pair in candidate.get("pairs") or []:
        annotation = _pair_annotation(pair, None)
        occurrences = pair.get("source_occurrences")
        if not occurrences:
            result.append(annotation)
            continue
        for occurrence in occurrences:
            value = copy.deepcopy(annotation)
            value["source_passage_indexes"] = list(occurrence)
            result.append(value)
    return result


def _routing_class_from_gold(decision: str) -> str:
    return {
        "valid_abbreviation_section": "ACCEPTED",
        "not_abbreviation_information": "REJECTED",
        "needs_parser_extension": "NEEDS_PARSER_EXTENSION",
    }[decision]


def _routing_class_from_prediction(disposition: str) -> str:
    if disposition in {"ACCEPTED", "ACCEPTED_WITH_REVIEW"}:
        return "ACCEPTED"
    if disposition in {"REJECTED", "NEEDS_PARSER_EXTENSION"}:
        return disposition
    return "UNRESOLVED_OR_ERROR"


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _f1(matched: int, predicted: int, gold: int) -> float | None:
    return 2 * matched / (predicted + gold) if predicted + gold else None


def _serialize_counter(counter: Counter[tuple[str, str]]) -> list[dict[str, Any]]:
    return [
        {"short_form": short_form, "long_form": long_form, "count": count}
        for (short_form, long_form), count in sorted(counter.items())
        if count
    ]


def _orientation_score(
    gold_pairs: list[Mapping[str, Any]], predicted_pairs: list[Mapping[str, Any]]
) -> tuple[int, int]:
    gold = Counter(
        (*_normalized_pair_key(pair), pair.get("orientation"))
        for pair in gold_pairs
        if pair.get("orientation") in {"FIRST_IS_SF", "SECOND_IS_SF"}
    )
    predicted = Counter(
        (*_normalized_pair_key(pair), pair.get("orientation"))
        for pair in predicted_pairs
        if pair.get("orientation") in {"FIRST_IS_SF", "SECOND_IS_SF"}
    )
    correct = sum((gold & predicted).values())
    gold_by_pair = Counter((short, long) for short, long, _ in gold.elements())
    predicted_by_pair = Counter(
        (short, long) for short, long, _ in predicted.elements()
    )
    eligible = sum((gold_by_pair & predicted_by_pair).values())
    return correct, eligible


def _new_aggregate() -> dict[str, int]:
    return {
        "sections": 0,
        "gold_pairs": 0,
        "predicted_pairs": 0,
        "matched_pairs": 0,
        "exact_pair_sections": 0,
    }


def _finalize_aggregate(value: Mapping[str, int]) -> dict[str, Any]:
    result = dict(value)
    result.update(
        {
            "pair_precision": _ratio(value["matched_pairs"], value["predicted_pairs"]),
            "pair_recall": _ratio(value["matched_pairs"], value["gold_pairs"]),
            "pair_f1": _f1(
                value["matched_pairs"], value["predicted_pairs"], value["gold_pairs"]
            ),
            "exact_pair_section_rate": _ratio(
                value["exact_pair_sections"], value["sections"]
            ),
        }
    )
    return result


def evaluate_snapshot(
    snapshot_dir: Path,
    report_dir: Path,
    output_dir: Path,
    baseline_id: str,
    *,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Evaluate the saved parser/Jev report against a versioned gold snapshot."""
    if output_dir.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite evaluation output: {output_dir}")
    if output_dir.exists() and not output_dir.is_dir():
        raise NotADirectoryError(f"Evaluation output is not a directory: {output_dir}")
    snapshot_manifest = json.loads(
        (snapshot_dir / "manifest.json").read_text(encoding="utf-8")
    )
    records = _read_jsonl(snapshot_dir / snapshot_manifest["records_file"])
    report_path = report_dir / "sequences.jsonl"
    report_rows = _read_jsonl(report_path)
    predictions: dict[tuple[str, str, int], Mapping[str, Any]] = {}
    duplicate_prediction_keys: list[tuple[str, str, int]] = []
    for row in report_rows:
        key = _report_key(row)
        if key in predictions:
            duplicate_prediction_keys.append(key)
            continue
        predictions[key] = row

    section_counts = Counter()
    routing_counts = Counter()
    gold_document_unique: set[tuple[str, str, str]] = set()
    predicted_document_unique: set[tuple[str, str, str]] = set()
    totals = {
        "gold_pairs": 0,
        "predicted_pairs": 0,
        "matched_normalized_pairs": 0,
        "matched_exact_pairs": 0,
        "exact_normalized_pair_sections": 0,
        "exact_source_string_pair_sections": 0,
        "endpoint_correct": 0,
        "endpoint_gold_positive_sections": 0,
        "endpoint_predicted_positive_sections": 0,
        "orientation_correct": 0,
        "orientation_eligible": 0,
    }
    by_pattern: defaultdict[str, dict[str, int]] = defaultdict(_new_aggregate)
    by_confidence: defaultdict[str, dict[str, int]] = defaultdict(_new_aggregate)
    per_section: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    for record in records:
        annotation = record["annotation"]
        prediction = predictions.get(_source_key(record))
        disposition = str((prediction or {}).get("disposition") or "MISSING")
        accepted_dispositions = {"ACCEPTED", "ACCEPTED_WITH_REVIEW"}
        candidate = (
            prediction.get("final_candidate")
            if prediction is not None and disposition in accepted_dispositions
            else None
        )
        if not isinstance(candidate, Mapping):
            candidate = None
        gold_decision = str(annotation["section_decision"])
        gold_positive = gold_decision == "valid_abbreviation_section"
        predicted_positive = candidate is not None
        if gold_decision != "needs_parser_extension":
            section_counts[(gold_positive, predicted_positive)] += 1
        gold_route = _routing_class_from_gold(gold_decision)
        predicted_route = _routing_class_from_prediction(disposition)
        routing_counts[(gold_route, predicted_route)] += 1

        gold_pairs = list(annotation.get("pairs") or [])
        predicted_pairs = _prediction_pairs(candidate)
        gold_normalized = _counter_pairs(gold_pairs, normalized=True)
        predicted_normalized = _counter_pairs(predicted_pairs, normalized=True)
        document_id = str(record["source"]["document_id"])
        gold_document_unique.update(
            (document_id, short, long) for short, long in gold_normalized
        )
        predicted_document_unique.update(
            (document_id, short, long) for short, long in predicted_normalized
        )
        matched_normalized = gold_normalized & predicted_normalized
        gold_exact = _counter_pairs(gold_pairs, normalized=False)
        predicted_exact = _counter_pairs(predicted_pairs, normalized=False)
        matched_exact = gold_exact & predicted_exact
        orientation_correct, orientation_eligible = _orientation_score(
            gold_pairs, predicted_pairs
        )
        gold_pair_count = sum(gold_normalized.values())
        predicted_pair_count = sum(predicted_normalized.values())
        normalized_match_count = sum(matched_normalized.values())
        exact_match_count = sum(matched_exact.values())
        normalized_section_exact = gold_normalized == predicted_normalized
        exact_section_exact = gold_exact == predicted_exact
        gold_end = annotation.get("end_index")
        predicted_end = candidate.get("end_index") if candidate else None
        endpoint_eligible = gold_positive and gold_end is not None
        endpoint_correct = (
            endpoint_eligible and candidate is not None and predicted_end == gold_end
        )

        totals["gold_pairs"] += gold_pair_count
        totals["predicted_pairs"] += predicted_pair_count
        totals["matched_normalized_pairs"] += normalized_match_count
        totals["matched_exact_pairs"] += exact_match_count
        totals["exact_normalized_pair_sections"] += normalized_section_exact
        totals["exact_source_string_pair_sections"] += exact_section_exact
        totals["orientation_correct"] += orientation_correct
        totals["orientation_eligible"] += orientation_eligible
        if endpoint_eligible:
            totals["endpoint_gold_positive_sections"] += 1
            totals["endpoint_correct"] += endpoint_correct
        if endpoint_eligible and predicted_positive:
            totals["endpoint_predicted_positive_sections"] += 1

        pattern = str(record.get("preannotation", {}).get("parser_pattern") or "UNKNOWN")
        confidence = float(record.get("preannotation", {}).get("confidence") or 0.0)
        confidence_bucket = (
            "low_<0.7"
            if confidence < 0.7
            else "mid_0.7_to_<0.9"
            if confidence < 0.9
            else "high_>=0.9"
        )
        for aggregate in (by_pattern[pattern], by_confidence[confidence_bucket]):
            aggregate["sections"] += 1
            aggregate["gold_pairs"] += gold_pair_count
            aggregate["predicted_pairs"] += predicted_pair_count
            aggregate["matched_pairs"] += normalized_match_count
            aggregate["exact_pair_sections"] += normalized_section_exact

        row = {
            "id": record["id"],
            "source": record["source"],
            "selection_tags": record.get("selection_tags") or [],
            "gold": {
                "section_decision": gold_decision,
                "positive": gold_positive,
                "routing_class": gold_route,
                "end_index": gold_end,
                "pair_count": gold_pair_count,
            },
            "prediction": {
                "disposition": disposition,
                "decision_source": (prediction or {}).get("decision_source"),
                "positive": predicted_positive,
                "routing_class": predicted_route,
                "pattern": candidate.get("pattern") if candidate else None,
                "end_index": predicted_end,
                "pair_count": predicted_pair_count,
                "error": (prediction or {}).get("error"),
            },
            "scores": {
                "matched_normalized_pairs": normalized_match_count,
                "matched_exact_pairs": exact_match_count,
                "normalized_pair_precision": _ratio(
                    normalized_match_count, predicted_pair_count
                ),
                "normalized_pair_recall": _ratio(
                    normalized_match_count, gold_pair_count
                ),
                "normalized_pair_f1": _f1(
                    normalized_match_count, predicted_pair_count, gold_pair_count
                ),
                "normalized_pair_multiset_exact": normalized_section_exact,
                "source_string_pair_multiset_exact": exact_section_exact,
                "endpoint_exact": endpoint_correct,
                "orientation_correct": orientation_correct,
                "orientation_eligible": orientation_eligible,
                "routing_exact": gold_route == predicted_route,
            },
            "false_negative_pairs": _serialize_counter(
                gold_normalized - predicted_normalized
            ),
            "false_positive_pairs": _serialize_counter(
                predicted_normalized - gold_normalized
            ),
        }
        per_section.append(row)
        if (
            gold_positive != predicted_positive
            or gold_route != predicted_route
            or not normalized_section_exact
            or (gold_positive and not endpoint_correct)
        ):
            errors.append(row)

    true_positive = section_counts[(True, True)]
    false_negative = section_counts[(True, False)]
    false_positive = section_counts[(False, True)]
    true_negative = section_counts[(False, False)]
    normalized_matched = totals["matched_normalized_pairs"]
    exact_matched = totals["matched_exact_pairs"]
    document_unique_matched = len(
        gold_document_unique & predicted_document_unique
    )
    acceptance_sections = sum(section_counts.values())
    routing_correct = sum(
        count
        for (gold_route, predicted_route), count in routing_counts.items()
        if gold_route == predicted_route
    )
    summary = {
        "schema_version": EVALUATION_SCHEMA_VERSION,
        "created_at": _utc_now(),
        "baseline_id": baseline_id,
        "snapshot_id": snapshot_manifest["snapshot_id"],
        "gold": {
            "sections": len(records),
            "positive_sections": true_positive + false_negative,
            "negative_sections": true_negative + false_positive,
            "parser_extension_sections": sum(
                record["annotation"]["section_decision"] == "needs_parser_extension"
                for record in records
            ),
            "pairs": totals["gold_pairs"],
            "annotation_grain": snapshot_manifest["annotation_grain"],
        },
        "section_acceptance": {
            "true_positive": true_positive,
            "false_negative": false_negative,
            "false_positive": false_positive,
            "true_negative": true_negative,
            "evaluated_sections": acceptance_sections,
            "excluded_gold_parser_extension_sections": len(records) - acceptance_sections,
            "accuracy": _ratio(true_positive + true_negative, acceptance_sections),
            "precision": _ratio(true_positive, true_positive + false_positive),
            "recall": _ratio(true_positive, true_positive + false_negative),
            "f1": _f1(
                true_positive,
                true_positive + false_positive,
                true_positive + false_negative,
            ),
        },
        "section_routing": {
            "correct": routing_correct,
            "sections": len(records),
            "accuracy": _ratio(routing_correct, len(records)),
            "confusion": {
                gold: {
                    predicted: routing_counts[(gold, predicted)]
                    for predicted in sorted({key[1] for key in routing_counts})
                    if routing_counts[(gold, predicted)]
                }
                for gold in sorted({key[0] for key in routing_counts})
            },
        },
        "normalized_occurrence_pairs": {
            "gold": totals["gold_pairs"],
            "predicted": totals["predicted_pairs"],
            "matched": normalized_matched,
            "precision": _ratio(normalized_matched, totals["predicted_pairs"]),
            "recall": _ratio(normalized_matched, totals["gold_pairs"]),
            "f1": _f1(
                normalized_matched, totals["predicted_pairs"], totals["gold_pairs"]
            ),
            "exact_sections": totals["exact_normalized_pair_sections"],
            "exact_section_rate": _ratio(
                totals["exact_normalized_pair_sections"], len(records)
            ),
        },
        "source_string_occurrence_pairs": {
            "matched": exact_matched,
            "precision": _ratio(exact_matched, totals["predicted_pairs"]),
            "recall": _ratio(exact_matched, totals["gold_pairs"]),
            "f1": _f1(
                exact_matched, totals["predicted_pairs"], totals["gold_pairs"]
            ),
            "exact_sections": totals["exact_source_string_pair_sections"],
            "exact_section_rate": _ratio(
                totals["exact_source_string_pair_sections"], len(records)
            ),
        },
        "document_unique_normalized_pairs": {
            "gold": len(gold_document_unique),
            "predicted": len(predicted_document_unique),
            "matched": document_unique_matched,
            "precision": _ratio(document_unique_matched, len(predicted_document_unique)),
            "recall": _ratio(document_unique_matched, len(gold_document_unique)),
            "f1": _f1(
                document_unique_matched,
                len(predicted_document_unique),
                len(gold_document_unique),
            ),
        },
        "endpoint": {
            "correct": totals["endpoint_correct"],
            "gold_positive_sections": totals["endpoint_gold_positive_sections"],
            "predicted_positive_sections": totals[
                "endpoint_predicted_positive_sections"
            ],
            "unconditional_accuracy": _ratio(
                totals["endpoint_correct"],
                totals["endpoint_gold_positive_sections"],
            ),
            "conditional_accuracy": _ratio(
                totals["endpoint_correct"],
                totals["endpoint_predicted_positive_sections"],
            ),
        },
        "orientation_on_matched_pairs": {
            "correct": totals["orientation_correct"],
            "eligible": totals["orientation_eligible"],
            "accuracy": _ratio(
                totals["orientation_correct"], totals["orientation_eligible"]
            ),
        },
        "by_gold_pattern": {
            key: _finalize_aggregate(value) for key, value in sorted(by_pattern.items())
        },
        "by_confidence": {
            key: _finalize_aggregate(value)
            for key, value in sorted(by_confidence.items())
        },
        "error_sections": len(errors),
        "report_integrity": {
            "prediction_rows": len(report_rows),
            "matched_gold_rows": sum(_source_key(record) in predictions for record in records),
            "duplicate_prediction_keys": [list(key) for key in duplicate_prediction_keys],
            "report_sha256": _sha256(report_path),
        },
        "caveats": [
            "The gold sample is risk-stratified, not a random corpus sample.",
            "Extraction acceptance treats ACCEPTED and ACCEPTED_WITH_REVIEW as positive and excludes gold parser-extension sections.",
            "Routing accuracy separately scores accepted, rejected, parser-extension, and unresolved/error outcomes.",
            "Canonical pair scoring case-folds, trims delimiter punctuation and known heading prefixes, and removes one full outer short-form parenthesis pair.",
            "Occurrence scoring expands source_occurrences; document-unique scoring deduplicates by document, short form, and long form.",
            "Endpoint accuracy excludes gold sections without an annotated endpoint.",
        ],
    }
    output_dir.mkdir(parents=True, exist_ok=overwrite)
    _write_json(output_dir / "summary.json", summary)
    _write_jsonl(output_dir / "per_section.jsonl", per_section)
    _write_jsonl(output_dir / "errors.jsonl", errors)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    snapshot = subparsers.add_parser("snapshot")
    snapshot.add_argument("--data-dir", type=Path, default=Path("annotations/abbreviations/gold"))
    snapshot.add_argument("--annotations", type=Path, required=True)
    snapshot.add_argument(
        "--output-root", type=Path, default=Path("annotations/abbreviations/gold/snapshots")
    )
    snapshot.add_argument("--version", required=True)
    evaluate = subparsers.add_parser("evaluate")
    evaluate.add_argument("--snapshot", type=Path, required=True)
    evaluate.add_argument(
        "--report-dir", type=Path, default=Path("experiments/abbreviations/reports/sample-jev-baseline")
    )
    evaluate.add_argument("--output-dir", type=Path, required=True)
    evaluate.add_argument("--baseline-id", default="current-jev-report")
    evaluate.add_argument(
        "--overwrite",
        action="store_true",
        help="replace the three generated evaluation files in an existing directory",
    )
    args = parser.parse_args()
    if args.command == "snapshot":
        result = create_snapshot(
            args.data_dir, args.annotations, args.output_root, args.version
        )
    else:
        result = evaluate_snapshot(
            args.snapshot,
            args.report_dir,
            args.output_dir,
            args.baseline_id,
            overwrite=args.overwrite,
        )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
